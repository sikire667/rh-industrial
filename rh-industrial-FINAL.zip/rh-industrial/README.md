# RH Industrial Pro

> Application RH complète pour société de chantier et maintenance industrielle  
> Laravel 11 · MySQL · Tailwind CSS · Chart.js

---

## 🚀 Installation rapide

```bash
# 1. Cloner / dézipper le projet
cd rh-industrial

# 2. Lancer l'installateur interactif
chmod +x install.sh && ./install.sh

# 3. Démarrer le serveur
php artisan serve
```

Accéder à **http://localhost:8000**

---

## 🔑 Comptes par défaut

| Rôle | Email | Mot de passe |
|------|-------|--------------|
| Administrateur | admin@rh-industrial.ma | password |
| RH Manager | rh@rh-industrial.ma | password |

---

## 📦 Stack technique

| Couche | Technologie |
|--------|-------------|
| Backend | **Laravel 11** (PHP 8.2+) |
| Base de données | **MySQL 8** |
| Frontend | **Blade** + **Tailwind CSS v3** |
| Graphiques | **Chart.js 4** |
| Export Excel | `maatwebsite/excel` |
| Export PDF | `barryvdh/laravel-dompdf` |
| Images | `intervention/image` |

---

## 🗂️ Modules

| Module | Description |
|--------|-------------|
| **Salariés** | Fiche complète, photo, CIN, contrats, chantier |
| **Pointage** | Présence quotidienne, heures sup, retards, rapport mensuel |
| **Absences** | 6 types, workflow approbation, taux absentéisme |
| **Documents** | Contrats, CIN, diplômes, habilitations, alertes expiration |
| **Disciplinaire** | Avertissements, mises à pied, observations |
| **Évaluations** | 7 critères, note auto, courbe d'évolution |
| **Formations** | SST/HSE, habilitations, alertes renouvellement |
| **EPI** | Stock, distribution, historique par salarié |
| **Rapports** | 6 rapports, export Excel + PDF |
| **Historique** | Journal d'audit complet horodaté |
| **Corbeille** | Soft-delete, restauration, suppression définitive (admin) |

---

## ⚙️ Commandes Artisan

```bash
# Vérifier et afficher toutes les alertes actives
php artisan rh:alertes

# Réinitialiser la BDD avec données de démo
php artisan migrate:fresh --seed

# Compiler les assets en mode dev (watch)
npm run dev

# Compiler pour production
npm run build
```

---

## 🔄 Tâche CRON (alertes automatiques)

Ajouter dans `/etc/crontab` ou `crontab -e` :

```cron
* * * * * cd /path/to/rh-industrial && php artisan schedule:run >> /dev/null 2>&1
```

---

## 📁 Structure principale

```
app/
├── Console/Commands/     # VerifierAlertes.php
├── Http/Controllers/     # 12 contrôleurs
├── Models/               # 15 modèles Eloquent
├── Observers/            # SalarieObserver (audit auto)
└── Services/             # AlerteService
database/
├── migrations/           # Toutes les tables
└── seeders/              # DatabaseSeeder (données démo)
resources/views/
├── layouts/              # app.blade, sidebar, topbar
├── dashboard/
├── salaries/
├── absences/
├── pointage/
├── documents/
├── evaluations/
├── formations/
├── epi/
├── disciplines/
├── rapports/
├── historique/
└── corbeille/
routes/web.php            # Toutes les routes
```

---

## 🔐 Rôles et permissions

| Rôle | Accès |
|------|-------|
| Administrateur | Tout, y compris corbeille définitive |
| RH Manager | Tous modules sauf suppression définitive |
| Superviseur Chantier | Pointage + lecture salariés/absences |

---

*Développé pour IndusMaint SARL — RH Industrial Pro v3.2*
