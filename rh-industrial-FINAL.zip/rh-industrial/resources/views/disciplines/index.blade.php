@extends('layouts.app')
@section('content')
<div class="p-6">
    <div class="bg-slate-900 border border-slate-800 rounded-2xl p-6">
        <h1 class="text-xl font-bold mb-2">Module RH</h1>
        <p class="text-slate-400">Cette page a été ajoutée pour éviter une erreur d’affichage. Le contrôleur et les données du module existent, mais la vue détaillée doit être finalisée.</p>
        <a href="{{ route('dashboard') }}" class="inline-block mt-4 px-4 py-2 rounded-lg bg-blue-600 text-white">Retour dashboard</a>
    </div>
</div>
@endsection
