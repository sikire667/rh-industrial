@extends('layouts.app')
@section('title','Historique')
@section('page_title','Journal de traçabilité')
@section('content')
<div class="flex gap-3 mb-5">
  <form class="flex gap-2 flex-1">
    <select name="module" class="bg-gray-900 border border-gray-800 rounded-lg px-3 py-2 text-sm text-gray-300 outline-none focus:border-blue-500">
      <option value="">Tous modules</option>
      @foreach($modules as $m)<option value="{{ $m }}" {{ request('module')==$m?'selected':'' }}>{{ ucfirst($m) }}</option>@endforeach
    </select>
    <input type="date" name="date" value="{{ request('date') }}" class="bg-gray-900 border border-gray-800 rounded-lg px-3 py-2 text-sm text-gray-300 outline-none focus:border-blue-500">
    <button class="px-3 py-2 bg-blue-600 hover:bg-blue-500 text-white text-sm rounded-lg">Filtrer</button>
    <a href="{{ route('historique.index') }}" class="px-3 py-2 bg-gray-800 hover:bg-gray-700 text-gray-300 text-sm rounded-lg">Reset</a>
  </form>
</div>
<div class="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
  <table class="w-full text-sm">
    <thead class="bg-gray-800"><tr>
      @foreach(['Date / Heure','Utilisateur','Action','Module','Entité']) 
      <th class="px-4 py-3 text-left text-xs font-semibold text-gray-400 uppercase tracking-wider">{{ $h }}</th>
      @endforeach
    </tr></thead>
    <tbody class="divide-y divide-gray-800">
      @forelse($logs as $log)
      <tr class="hover:bg-gray-800/40">
        <td class="px-4 py-3 font-mono text-xs text-gray-500">{{ $log->created_at->format('d/m/Y H:i:s') }}</td>
        <td class="px-4 py-3 font-medium text-gray-200">{{ $log->user?->name ?? 'Système' }}</td>
        <td class="px-4 py-3">
          @php $ac=['creation'=>'bg-emerald-500/10 text-emerald-400','modification'=>'bg-blue-500/10 text-blue-400','suppression'=>'bg-red-500/10 text-red-400','connexion'=>'bg-purple-500/10 text-purple-400'][$log->action]??'bg-gray-700 text-gray-300'; @endphp
          <span class="px-2 py-0.5 rounded-full text-xs {{ $ac }}">{{ $log->action }}</span>
        </td>
        <td class="px-4 py-3 text-gray-400">{{ $log->module }}</td>
        <td class="px-4 py-3 text-xs text-gray-500 font-mono">{{ $log->entite_type ? class_basename($log->entite_type).' #'.$log->entite_id : '—' }}</td>
      </tr>
      @empty
      <tr><td colspan="5" class="py-8 text-center text-gray-600">Aucune entrée</td></tr>
      @endforelse
    </tbody>
  </table>
</div>
<div class="mt-4">{{ $logs->links() }}</div>
@endsection
