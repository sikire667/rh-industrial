@extends('layouts.app')
@section('title','Corbeille')
@section('page_title','Corbeille — Éléments supprimés')
@section('content')
@foreach([['salaries','Salariés','fa-users',$salaries],['documents','Documents','fa-folder',$documents],['disciplines','Disciplinaire','fa-gavel',$disciplines]] as [$type,$label,$icon,$items])
<div class="bg-gray-900 border border-gray-800 rounded-xl mb-4 overflow-hidden">
  <div class="px-5 py-3 border-b border-gray-800 flex items-center gap-2">
    <i class="fas {{ $icon }} text-gray-400"></i>
    <span class="text-sm font-semibold">{{ $label }}</span>
    <span class="px-2 py-0.5 bg-gray-800 text-gray-400 text-xs rounded-full ml-auto">{{ $items->count() }}</span>
  </div>
  @if($items->count())
  <table class="w-full text-sm">
    <thead class="bg-gray-800"><tr>
      <th class="px-4 py-2 text-left text-xs text-gray-400 uppercase">Élément</th>
      <th class="px-4 py-2 text-left text-xs text-gray-400 uppercase">Supprimé le</th>
      <th class="px-4 py-2 text-left text-xs text-gray-400 uppercase">Actions</th>
    </tr></thead>
    <tbody class="divide-y divide-gray-800">
      @foreach($items as $item)
      <tr class="hover:bg-gray-800/40">
        <td class="px-4 py-3 text-gray-300">{{ $item->nom_complet ?? $item->titre ?? "#{$item->id}" }}</td>
        <td class="px-4 py-3 text-xs text-gray-500">{{ $item->deleted_at->format('d/m/Y H:i') }}</td>
        <td class="px-4 py-3">
          <div class="flex gap-2">
            <form method="POST" action="{{ route('corbeille.restaurer') }}">
              @csrf <input type="hidden" name="type" value="{{ $type }}"><input type="hidden" name="id" value="{{ $item->id }}">
              <button class="px-3 py-1 bg-emerald-900/50 hover:bg-emerald-700 text-emerald-400 text-xs rounded-lg">↩ Restaurer</button>
            </form>
            <form method="POST" action="{{ route('corbeille.supprimer') }}" onsubmit="return confirm('Supprimer définitivement ?')">
              @csrf @method('DELETE') <input type="hidden" name="type" value="{{ $type }}"><input type="hidden" name="id" value="{{ $item->id }}">
              <button class="px-3 py-1 bg-red-900/50 hover:bg-red-700 text-red-400 text-xs rounded-lg">🗑 Supprimer</button>
            </form>
          </div>
        </td>
      </tr>
      @endforeach
    </tbody>
  </table>
  @else
  <div class="py-6 text-center text-gray-600 text-sm"><i class="fas fa-check-circle text-emerald-500 block text-xl mb-1 opacity-50"></i>Vide</div>
  @endif
</div>
@endforeach
@endsection
