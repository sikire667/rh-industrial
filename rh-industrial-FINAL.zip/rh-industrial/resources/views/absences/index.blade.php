@extends('layouts.app')
@section('title','Absences')
@section('page_title','Gestion des absences')
@section('content')
<div class="grid grid-cols-4 gap-4 mb-6">
  @foreach([
    ['Taux absentéisme',$stats['taux'].'%','fa-chart-line','text-amber-400','bg-amber-500/10'],
    ['En attente',$stats['en_attente'],'fa-clock','text-blue-400','bg-blue-500/10'],
    ['Injustifiées (mois)',$stats['injustifiees_mois'],'fa-xmark','text-red-400','bg-red-500/10'],
    ['Congés (mois)',$stats['conges_mois'],'fa-umbrella-beach','text-emerald-400','bg-emerald-500/10'],
  ] as [$l,$v,$i,$tc,$bg])
  <div class="bg-gray-900 border border-gray-800 rounded-xl p-5">
    <div class="w-9 h-9 rounded-lg {{ $bg }} {{ $tc }} flex items-center justify-center mb-3"><i class="fas {{ $i }}"></i></div>
    <div class="text-2xl font-bold">{{ $v }}</div>
    <div class="text-sm text-gray-400">{{ $l }}</div>
  </div>
  @endforeach
</div>

<div class="grid grid-cols-3 gap-4 mb-4">
  <div class="col-span-2 bg-gray-900 border border-gray-800 rounded-xl p-5">
    <div class="flex items-center justify-between mb-4">
      <span class="text-sm font-semibold">Liste des absences</span>
      <button onclick="document.getElementById('modalAbsence').classList.remove('hidden')" class="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-medium rounded-lg">+ Déclarer</button>
    </div>
    <table class="w-full text-sm">
      <thead class="text-xs text-gray-500 uppercase"><tr>
        @foreach(['Salarié','Type','Période','Jours','Statut','Actions'] as $h)
        <th class="pb-2 text-left font-semibold tracking-wider">{{ $h }}</th>
        @endforeach
      </tr></thead>
      <tbody class="divide-y divide-gray-800">
        @forelse($absences as $a)
        <tr class="hover:bg-gray-800/30">
          <td class="py-3 font-medium text-gray-200">{{ $a->salarie->nom_complet }}</td>
          <td class="py-3">
            @php $types=['conge_annuel'=>['Congé annuel','bg-blue-500/10 text-blue-400'],'conge_maladie'=>['Maladie','bg-purple-500/10 text-purple-400'],'absence_non_justifiee'=>['Injustifiée','bg-red-500/10 text-red-400'],'absence_justifiee'=>['Justifiée','bg-emerald-500/10 text-emerald-400'],'retard'=>['Retard','bg-amber-500/10 text-amber-400'],'conge_sans_solde'=>['Sans solde','bg-gray-500/10 text-gray-400']]; $t=$types[$a->type]??[$a->type,'bg-gray-700 text-gray-300']; @endphp
            <span class="px-2 py-0.5 rounded-full text-xs {{ $t[1] }}">{{ $t[0] }}</span>
          </td>
          <td class="py-3 text-xs text-gray-400">{{ $a->date_debut->format('d/m') }} → {{ $a->date_fin->format('d/m/Y') }}</td>
          <td class="py-3 font-medium">{{ $a->nb_jours }}j</td>
          <td class="py-3">
            @php $sc=['en_attente'=>'text-amber-400','approuve'=>'text-emerald-400','refuse'=>'text-red-400'][$a->statut]??'text-gray-400'; @endphp
            <span class="text-xs {{ $sc }}">{{ ['en_attente'=>'⏳ En attente','approuve'=>'✅ Approuvé','refuse'=>'❌ Refusé'][$a->statut] }}</span>
          </td>
          <td class="py-3">
            @if($a->statut==='en_attente')
            <div class="flex gap-1">
              <form method="POST" action="{{ route('absences.valider',$a) }}">@csrf @method('PATCH')
                <button class="w-6 h-6 bg-emerald-900/50 hover:bg-emerald-700 text-emerald-400 rounded text-xs">✓</button>
              </form>
              <form method="POST" action="{{ route('absences.refuser',$a) }}">@csrf @method('PATCH')
                <button class="w-6 h-6 bg-red-900/50 hover:bg-red-700 text-red-400 rounded text-xs">✗</button>
              </form>
            </div>
            @endif
          </td>
        </tr>
        @empty
        <tr><td colspan="6" class="py-8 text-center text-gray-600">Aucune absence trouvée</td></tr>
        @endforelse
      </tbody>
    </table>
    <div class="mt-3">{{ $absences->links() }}</div>
  </div>

  <div class="bg-gray-900 border border-gray-800 rounded-xl p-5">
    <div class="text-sm font-semibold mb-3">Historique taux absentéisme</div>
    <canvas id="chartAbsence" height="200"></canvas>
  </div>
</div>

{{-- Modal --}}
<div id="modalAbsence" class="hidden fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
  <div class="bg-gray-900 border border-gray-800 rounded-2xl w-full max-w-lg">
    <div class="flex items-center justify-between p-5 border-b border-gray-800">
      <h3 class="font-semibold">Déclarer une absence</h3>
      <button onclick="document.getElementById('modalAbsence').classList.add('hidden')" class="w-8 h-8 rounded-lg bg-gray-800 flex items-center justify-center text-gray-400 hover:text-gray-200">✕</button>
    </div>
    <form method="POST" action="{{ route('absences.store') }}" enctype="multipart/form-data" class="p-5 space-y-3">
      @csrf
      <div class="grid grid-cols-2 gap-3">
        <div class="col-span-2"><label class="text-xs text-gray-400 block mb-1">Salarié</label>
          <select name="salarie_id" required class="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-gray-300 outline-none focus:border-blue-500">
            <option value="">Choisir...</option>
            @foreach(\App\Models\Salarie::actif()->orderBy('nom')->get() as $s)
            <option value="{{ $s->id }}">{{ $s->nom_complet }} ({{ $s->matricule }})</option>
            @endforeach
          </select>
        </div>
        <div><label class="text-xs text-gray-400 block mb-1">Type</label>
          <select name="type" required class="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-gray-300 outline-none focus:border-blue-500">
            @foreach(['conge_annuel'=>'Congé annuel','conge_maladie'=>'Congé maladie','conge_sans_solde'=>'Sans solde','absence_justifiee'=>'Justifiée','absence_non_justifiee'=>'Non justifiée','retard'=>'Retard'] as $v=>$l)
            <option value="{{ $v }}">{{ $l }}</option>
            @endforeach
          </select>
        </div>
        <div><label class="text-xs text-gray-400 block mb-1">Du</label>
          <input type="date" name="date_debut" required class="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-gray-300 outline-none focus:border-blue-500">
        </div>
        <div><label class="text-xs text-gray-400 block mb-1">Au</label>
          <input type="date" name="date_fin" required class="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-gray-300 outline-none focus:border-blue-500">
        </div>
        <div class="col-span-2"><label class="text-xs text-gray-400 block mb-1">Motif</label>
          <textarea name="motif" rows="2" class="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-gray-300 outline-none focus:border-blue-500 resize-none"></textarea>
        </div>
        <div class="col-span-2"><label class="text-xs text-gray-400 block mb-1">Justificatif (facultatif)</label>
          <input type="file" name="justificatif" class="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-gray-300">
        </div>
      </div>
      <div class="flex gap-2 justify-end pt-2">
        <button type="button" onclick="document.getElementById('modalAbsence').classList.add('hidden')" class="px-4 py-2 bg-gray-800 text-gray-300 text-sm rounded-lg hover:bg-gray-700">Annuler</button>
        <button type="submit" class="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-sm font-medium rounded-lg">Enregistrer</button>
      </div>
    </form>
  </div>
</div>
@endsection
@push('scripts')
<script>
const hist=@json($historique);
new Chart('chartAbsence',{type:'line',data:{labels:hist.map(h=>h.mois),datasets:[{label:'Taux %',data:hist.map(h=>h.taux),borderColor:'#f59e0b',backgroundColor:'rgba(245,158,11,.1)',fill:true,tension:.4,pointRadius:3,pointBackgroundColor:'#f59e0b',borderWidth:2}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{x:{grid:{color:'rgba(255,255,255,.04)'},ticks:{font:{size:10}}},y:{grid:{color:'rgba(255,255,255,.04)'},beginAtZero:true}}}});
</script>
@endpush
