@extends('layouts.app')
@section('title','Salariés')
@section('page_title','Gestion des salariés')
@section('content')
<div class="flex items-center justify-between mb-5">
  <div class="grid grid-cols-5 gap-3">
    @foreach([['Total',       $stats['total'],   'text-blue-400'],
              ['CDI',         $stats['cdi'],     'text-emerald-400'],
              ['CDD',         $stats['cdd'],     'text-amber-400'],
              ['Intérim',     $stats['interim'], 'text-purple-400']] as [$l,$v,$c])
    <div class="bg-gray-900 border border-gray-800 rounded-xl px-4 py-3 text-center">
      <div class="text-xl font-bold {{ $c }}">{{ $v }}</div>
      <div class="text-xs text-gray-500">{{ $l }}</div>
    </div>
    @endforeach
  </div>
  <a href="{{ route('salaries.create') }}" class="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-sm font-medium rounded-lg transition-colors">
    <i class="fas fa-plus"></i> Nouveau salarié
  </a>
</div>

{{-- Filtres --}}
<form class="flex gap-3 mb-4">
  <input name="search" value="{{ request('search') }}" placeholder="Nom, matricule, CIN..."
    class="bg-gray-900 border border-gray-800 rounded-lg px-3 py-2 text-sm text-gray-300 placeholder-gray-600 outline-none focus:border-blue-500 w-64">
  <select name="contrat" class="bg-gray-900 border border-gray-800 rounded-lg px-3 py-2 text-sm text-gray-300 outline-none focus:border-blue-500">
    <option value="">Tous contrats</option>
    @foreach(['CDI','CDD','Interim'] as $c)<option value="{{ $c }}" {{ request('contrat')==$c?'selected':'' }}>{{ $c }}</option>@endforeach
  </select>
  <select name="chantier_id" class="bg-gray-900 border border-gray-800 rounded-lg px-3 py-2 text-sm text-gray-300 outline-none focus:border-blue-500">
    <option value="">Tous chantiers</option>
    @foreach($chantiers as $ch)<option value="{{ $ch->id }}" {{ request('chantier_id')==$ch->id?'selected':'' }}>{{ $ch->nom }}</option>@endforeach
  </select>
  <button class="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-sm rounded-lg">Filtrer</button>
  <a href="{{ route('salaries.index') }}" class="px-4 py-2 bg-gray-800 hover:bg-gray-700 text-gray-300 text-sm rounded-lg">Réinitialiser</a>
</form>

<div class="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
  <table class="w-full text-sm">
    <thead class="bg-gray-800">
      <tr>
        @foreach(['Matricule','Salarié','Fonction','Chantier','Contrat','Embauche','Statut','Actions'] as $h)
        <th class="px-4 py-3 text-left text-xs font-semibold text-gray-400 uppercase tracking-wider">{{ $h }}</th>
        @endforeach
      </tr>
    </thead>
    <tbody class="divide-y divide-gray-800">
      @forelse($salaries as $s)
      <tr class="hover:bg-gray-800/50 transition-colors">
        <td class="px-4 py-3 font-mono text-xs text-cyan-400">{{ $s->matricule }}</td>
        <td class="px-4 py-3">
          <div class="flex items-center gap-3">
            <div class="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-xs font-bold flex-shrink-0">
              {{ strtoupper(substr($s->prenom,0,1).substr($s->nom,0,1)) }}
            </div>
            <div>
              <div class="font-medium text-gray-200">{{ $s->nom_complet }}</div>
              <div class="text-xs text-gray-500">{{ $s->cin }}</div>
            </div>
          </div>
        </td>
        <td class="px-4 py-3 text-gray-300">{{ $s->fonction?->libelle ?? '—' }}</td>
        <td class="px-4 py-3">
          @if($s->chantier)
          <span class="px-2 py-0.5 rounded-full text-xs bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">{{ $s->chantier->nom }}</span>
          @else<span class="text-gray-600">—</span>@endif
        </td>
        <td class="px-4 py-3">
          @php $cc=['CDI'=>'bg-emerald-500/10 text-emerald-400 border-emerald-500/20','CDD'=>'bg-amber-500/10 text-amber-400 border-amber-500/20','Interim'=>'bg-red-500/10 text-red-400 border-red-500/20'][$s->type_contrat]??''; @endphp
          <span class="px-2 py-0.5 rounded-full text-xs border {{ $cc }}">{{ $s->type_contrat }}</span>
        </td>
        <td class="px-4 py-3 text-xs text-gray-400">{{ $s->date_embauche->format('d/m/Y') }}</td>
        <td class="px-4 py-3">
          @php $sc=['actif'=>'bg-emerald-500/10 text-emerald-400','inactif'=>'bg-gray-500/10 text-gray-400','suspendu'=>'bg-amber-500/10 text-amber-400'][$s->statut]??''; @endphp
          <span class="px-2 py-0.5 rounded-full text-xs {{ $sc }}">● {{ ucfirst($s->statut) }}</span>
          @if($s->hasDocumentsExpires())
          <span class="ml-1 px-1.5 py-0.5 rounded text-xs bg-red-500/10 text-red-400">Doc!</span>
          @endif
        </td>
        <td class="px-4 py-3">
          <div class="flex gap-1.5">
            <a href="{{ route('salaries.show', $s) }}" class="w-7 h-7 flex items-center justify-center rounded bg-gray-800 hover:bg-gray-700 text-gray-400 hover:text-gray-200 text-xs"><i class="fas fa-eye"></i></a>
            <a href="{{ route('salaries.edit', $s) }}" class="w-7 h-7 flex items-center justify-center rounded bg-gray-800 hover:bg-gray-700 text-gray-400 hover:text-gray-200 text-xs"><i class="fas fa-pen"></i></a>
            <form method="POST" action="{{ route('salaries.destroy', $s) }}" onsubmit="return confirm('Archiver ce salarié ?')">
              @csrf @method('DELETE')
              <button class="w-7 h-7 flex items-center justify-center rounded bg-gray-800 hover:bg-red-900 text-gray-400 hover:text-red-400 text-xs"><i class="fas fa-trash"></i></button>
            </form>
          </div>
        </td>
      </tr>
      @empty
      <tr><td colspan="8" class="px-4 py-10 text-center text-gray-600"><i class="fas fa-users text-3xl mb-2 block opacity-30"></i>Aucun salarié trouvé</td></tr>
      @endforelse
    </tbody>
  </table>
</div>
<div class="mt-4">{{ $salaries->links() }}</div>
@endsection
