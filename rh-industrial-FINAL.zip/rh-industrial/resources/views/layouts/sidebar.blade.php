<aside class="w-60 bg-gray-900 border-r border-gray-800 flex flex-col flex-shrink-0 overflow-y-auto">
    {{-- Logo --}}
    <div class="p-4 border-b border-gray-800 flex items-center gap-3">
        <div class="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-lg">⚙️</div>
        <div>
            <div class="text-sm font-bold leading-tight">RH Industrial</div>
            <div class="text-xs text-gray-500">Pro Suite v3.2</div>
        </div>
    </div>

    <nav class="flex-1 p-2">
        <div class="text-xs font-bold uppercase tracking-widest text-gray-600 px-3 py-2 mt-2">Principal</div>
        @php
        $navItems = [
            ['dashboard', 'fas fa-chart-pie', 'Tableau de bord'],
            ['salaries.index', 'fas fa-users', 'Salariés', \App\Models\Salarie::actif()->count()],
            ['pointage.index', 'fas fa-clock', 'Pointage'],
            ['absences.index', 'fas fa-calendar-xmark', 'Absences', \App\Models\Absence::where('statut','en_attente')->count()],
        ];
        $mgmtItems = [
            ['documents.index', 'fas fa-folder-open', 'Documents', \App\Models\Document::expires()->count() + \App\Models\Document::bientotExpires(30)->count()],
            ['disciplines.index', 'fas fa-gavel', 'Disciplinaire'],
            ['evaluations.index', 'fas fa-star', 'Évaluations'],
            ['formations.index', 'fas fa-graduation-cap', 'Formations', \App\Models\SalarieFormation::where('statut','expire')->count()],
            ['epi.index', 'fas fa-hard-hat', 'EPI'],
        ];
        $reportItems = [
            ['rapports.index', 'fas fa-chart-bar', 'Rapports'],
            ['historique.index', 'fas fa-list-check', 'Historique'],
            ['corbeille.index', 'fas fa-trash', 'Corbeille'],
        ];
        @endphp

        @foreach($navItems as [$route, $icon, $label, $badge])
        <a href="{{ route($route) }}" class="flex items-center gap-3 px-3 py-2 my-0.5 rounded-lg text-sm transition-all {{ request()->routeIs(explode('.', $route)[0].'*') ? 'bg-blue-500/10 text-blue-400 font-medium' : 'text-gray-400 hover:bg-gray-800 hover:text-gray-200' }}">
            <i class="{{ $icon }} w-4 text-center"></i>
            <span class="flex-1">{{ $label }}</span>
            @if(!empty($badge) && $badge > 0)
                <span class="text-xs font-bold px-1.5 py-0.5 rounded-full bg-blue-500 text-white">{{ $badge }}</span>
            @endif
        </a>
        @endforeach

        <div class="text-xs font-bold uppercase tracking-widest text-gray-600 px-3 py-2 mt-3">Gestion</div>
        @foreach($mgmtItems as [$route, $icon, $label, $badge])
        <a href="{{ route($route) }}" class="flex items-center gap-3 px-3 py-2 my-0.5 rounded-lg text-sm transition-all {{ request()->routeIs(explode('.', $route)[0].'*') ? 'bg-blue-500/10 text-blue-400 font-medium' : 'text-gray-400 hover:bg-gray-800 hover:text-gray-200' }}">
            <i class="{{ $icon }} w-4 text-center"></i>
            <span class="flex-1">{{ $label }}</span>
            @if(!empty($badge) && $badge > 0)
                <span class="text-xs font-bold px-1.5 py-0.5 rounded-full bg-red-500 text-white">{{ $badge }}</span>
            @endif
        </a>
        @endforeach

        <div class="text-xs font-bold uppercase tracking-widest text-gray-600 px-3 py-2 mt-3">Rapports</div>
        @foreach($reportItems as [$route, $icon, $label])
        <a href="{{ route($route) }}" class="flex items-center gap-3 px-3 py-2 my-0.5 rounded-lg text-sm transition-all {{ request()->routeIs(explode('.', $route)[0].'*') ? 'bg-blue-500/10 text-blue-400 font-medium' : 'text-gray-400 hover:bg-gray-800 hover:text-gray-200' }}">
            <i class="{{ $icon }} w-4 text-center"></i>
            <span>{{ $label }}</span>
        </a>
        @endforeach
    </nav>

    {{-- User footer --}}
    <div class="p-3 border-t border-gray-800">
        <div class="flex items-center gap-3 p-2 rounded-lg bg-gray-800">
            <div class="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-blue-600 flex items-center justify-center text-xs font-bold">
                {{ strtoupper(substr(auth()->user()->name, 0, 2)) }}
            </div>
            <div class="flex-1 min-w-0">
                <div class="text-xs font-semibold truncate">{{ auth()->user()->name }}</div>
                <div class="text-xs text-gray-500">{{ auth()->user()->role?->nom ?? 'Utilisateur' }}</div>
            </div>
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button class="text-gray-500 hover:text-gray-300 text-sm"><i class="fas fa-right-from-bracket"></i></button>
            </form>
        </div>
    </div>
</aside>
