<header class="h-14 bg-gray-900 border-b border-gray-800 flex items-center px-6 gap-4 flex-shrink-0">
    <h1 class="text-sm font-semibold flex-1">@yield('page_title', 'Tableau de bord')</h1>

    {{-- Recherche globale --}}
    <div class="flex items-center gap-2 bg-gray-800 border border-gray-700 rounded-lg px-3 h-9 w-72">
        <i class="fas fa-magnifying-glass text-gray-500 text-xs"></i>
        <input type="text" placeholder="Rechercher un salarié, document..."
               class="bg-transparent text-sm text-gray-300 placeholder-gray-600 outline-none flex-1"
               id="globalSearch">
    </div>

    {{-- Alertes --}}
    <div class="relative" x-data="{ open: false }">
        <button @click="open = !open" class="w-9 h-9 rounded-lg bg-gray-800 border border-gray-700 flex items-center justify-center text-gray-400 hover:text-gray-200 relative">
            <i class="fas fa-bell text-sm"></i>
            @php $nbAlertes = \App\Models\Document::expires()->count() + \App\Models\SalarieFormation::where('statut','expire')->count(); @endphp
            @if($nbAlertes > 0)
                <span class="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full border-2 border-gray-900"></span>
            @endif
        </button>
    </div>

    <a href="{{ route('rapports.index') }}" class="w-9 h-9 rounded-lg bg-gray-800 border border-gray-700 flex items-center justify-center text-gray-400 hover:text-gray-200">
        <i class="fas fa-download text-sm"></i>
    </a>
</header>
