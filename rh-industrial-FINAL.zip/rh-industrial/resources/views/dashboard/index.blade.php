@extends('layouts.app')
@section('title', 'Tableau de bord')
@section('page_title', 'Tableau de bord RH')
@section('content')
<div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
@php
$cards = [
  ['Effectif total',       $kpis['effectif_total'],   'fa-users',              'text-blue-400',   'bg-blue-500/10'],
  ['Présents aujourd\'hui',$kpis['presents_today'],  'fa-circle-check',       'text-emerald-400','bg-emerald-500/10'],
  ['Absents',              $kpis['absents_today'],    'fa-user-xmark',         'text-amber-400',  'bg-amber-500/10'],
  ['Alertes actives',      $kpis['alertes_total'],    'fa-triangle-exclamation','text-red-400',   'bg-red-500/10'],
];
@endphp
@foreach($cards as [$label,$val,$icon,$tc,$bg])
<div class="bg-gray-900 border border-gray-800 rounded-xl p-5 hover:border-gray-700 transition-colors">
  <div class="w-10 h-10 rounded-lg {{ $bg }} {{ $tc }} flex items-center justify-center mb-3">
    <i class="fas {{ $icon }} text-lg"></i>
  </div>
  <div class="text-3xl font-bold mb-1">{{ $val }}</div>
  <div class="text-sm text-gray-400">{{ $label }}</div>
</div>
@endforeach
</div>

<div class="grid grid-cols-3 gap-4 mb-4">
  <div class="col-span-2 bg-gray-900 border border-gray-800 rounded-xl p-5">
    <div class="flex items-center justify-between mb-4">
      <span class="text-sm font-semibold">Présences — 30 derniers jours</span>
      <div class="flex gap-3 text-xs text-gray-400">
        <span class="flex items-center gap-1"><span class="w-2 h-2 rounded-full bg-emerald-500 inline-block"></span>Présents</span>
        <span class="flex items-center gap-1"><span class="w-2 h-2 rounded-full bg-red-500 inline-block"></span>Absents</span>
      </div>
    </div>
    <canvas id="chartPresence" height="90"></canvas>
  </div>
  <div class="bg-gray-900 border border-gray-800 rounded-xl p-5">
    <div class="text-sm font-semibold mb-4">Répartition chantiers</div>
    <canvas id="chartChantier" height="160"></canvas>
  </div>
</div>

<div class="grid grid-cols-3 gap-4 mb-4">
  <div class="bg-gray-900 border border-gray-800 rounded-xl p-5">
    <div class="text-sm font-semibold mb-4">Types de contrats</div>
    <canvas id="chartContrats" height="130"></canvas>
  </div>
  <div class="bg-gray-900 border border-gray-800 rounded-xl p-5">
    <div class="text-sm font-semibold mb-2">Taux d'absentéisme</div>
    <div class="text-3xl font-bold text-amber-400 mb-3">{{ $kpis['taux_absenteisme'] }}%</div>
    @foreach([['Congés annuels',3.2,'bg-blue-500'],['Abs. injustifiées',1.8,'bg-red-500'],['Maladie',2.1,'bg-amber-500'],['Sans solde',0.5,'bg-gray-600']] as [$l,$p,$c])
    <div class="mb-2"><div class="flex justify-between text-xs mb-1"><span class="text-gray-400">{{ $l }}</span><span>{{ $p }}%</span></div>
    <div class="h-1.5 bg-gray-800 rounded-full"><div class="{{ $c }} h-full rounded-full" style="width:{{ min($p*10,100) }}%"></div></div></div>
    @endforeach
  </div>
  <div class="bg-gray-900 border border-gray-800 rounded-xl p-5">
    <div class="flex items-center justify-between mb-3">
      <span class="text-sm font-semibold">Alertes urgentes</span>
      <span class="text-xs px-2 py-0.5 bg-red-500/10 text-red-400 rounded-full border border-red-500/20">{{ count($alertes) }}</span>
    </div>
    <div class="space-y-2 max-h-44 overflow-y-auto">
      @forelse($alertes as $a)
      <div class="flex gap-2 p-2 rounded-lg bg-gray-800 border border-gray-700">
        <div class="w-2 h-2 rounded-full flex-shrink-0 mt-1.5 {{ $a['type']==='danger' ? 'bg-red-500' : 'bg-amber-500' }}"></div>
        <div class="text-xs text-gray-300 leading-relaxed">{{ $a['msg'] }}</div>
      </div>
      @empty
      <div class="text-center py-4 text-gray-600 text-sm"><i class="fas fa-check-circle text-emerald-500 block text-xl mb-1"></i>Aucune alerte</div>
      @endforelse
    </div>
  </div>
</div>

<div class="bg-gray-900 border border-gray-800 rounded-xl p-5">
  <div class="flex items-center justify-between mb-4">
    <span class="text-sm font-semibold">Activité récente</span>
    <a href="{{ route('historique.index') }}" class="text-xs text-blue-400 hover:text-blue-300">Voir tout →</a>
  </div>
  @foreach($activite as $log)
  <div class="flex items-start gap-3 py-2 border-b border-gray-800 last:border-0">
    <div class="w-2 h-2 rounded-full bg-blue-500 flex-shrink-0 mt-1.5"></div>
    <div class="flex-1 text-sm"><span class="text-gray-300 font-medium">{{ $log->user?->name ?? 'Système' }}</span> <span class="text-gray-500">— {{ $log->action }} / {{ $log->module }}</span></div>
    <div class="text-xs text-gray-600">{{ $log->created_at->diffForHumans() }}</div>
  </div>
  @endforeach
</div>
@endsection
@push('scripts')
<script>
Chart.defaults.color='#6b7280';
const p30=@json($presences30j);
new Chart('chartPresence',{type:'line',data:{labels:p30.map(d=>d.date),datasets:[{label:'Présents',data:p30.map(d=>d.presents),borderColor:'#10b981',backgroundColor:'rgba(16,185,129,.08)',fill:true,tension:.4,pointRadius:0,borderWidth:2},{label:'Absents',data:p30.map(d=>d.absents),borderColor:'#ef4444',backgroundColor:'rgba(239,68,68,.06)',fill:true,tension:.4,pointRadius:0,borderWidth:2}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{x:{grid:{color:'rgba(255,255,255,.04)'},ticks:{maxTicksLimit:10}},y:{grid:{color:'rgba(255,255,255,.04)'},min:0}}}});
const ch=@json($parChantier);
new Chart('chartChantier',{type:'doughnut',data:{labels:ch.map(c=>c.nom),datasets:[{data:ch.map(c=>c.effectif),backgroundColor:['#3b82f6','#10b981','#f59e0b','#8b5cf6','#06b6d4'],borderWidth:0}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'bottom',labels:{padding:8,usePointStyle:true,font:{size:10}}}},cutout:'65%'}});
const ct=@json($parContrat);
new Chart('chartContrats',{type:'bar',data:{labels:Object.keys(ct),datasets:[{data:Object.values(ct),backgroundColor:['#3b82f6','#10b981','#f59e0b'],borderRadius:6,borderSkipped:false}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{x:{grid:{display:false}},y:{grid:{color:'rgba(255,255,255,.04)'}}}}});
</script>
@endpush
