@extends('layouts.app')
@section('title','Pointage')
@section('page_title','Gestion du pointage')
@section('content')
<div class="flex items-center justify-between mb-5">
  <form class="flex gap-2">
    <input type="date" name="date" value="{{ $date->format('Y-m-d') }}" class="bg-gray-900 border border-gray-800 rounded-lg px-3 py-2 text-sm text-gray-300 outline-none focus:border-blue-500">
    <button class="px-3 py-2 bg-blue-600 hover:bg-blue-500 text-white text-sm rounded-lg">Afficher</button>
  </form>
  <button onclick="document.getElementById('modalPointage').classList.remove('hidden')" class="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-sm font-medium rounded-lg flex items-center gap-2">
    <i class="fas fa-plus"></i> Pointage manuel
  </button>
</div>

<div class="grid grid-cols-4 gap-4 mb-5">
  @foreach([
    ['Présents',$stats['presents'],'fa-circle-check','text-emerald-400','bg-emerald-500/10'],
    ['Retards',$stats['retards'],'fa-clock','text-amber-400','bg-amber-500/10'],
    ['Absents',$stats['absents'],'fa-user-xmark','text-red-400','bg-red-500/10'],
    ['H. supp.',$stats['heures_sup'].'h','fa-plus-circle','text-blue-400','bg-blue-500/10'],
  ] as [$l,$v,$i,$tc,$bg])
  <div class="bg-gray-900 border border-gray-800 rounded-xl p-4">
    <div class="w-9 h-9 rounded-lg {{ $bg }} {{ $tc }} flex items-center justify-center mb-2"><i class="fas {{ $i }}"></i></div>
    <div class="text-2xl font-bold">{{ $v }}</div><div class="text-xs text-gray-400">{{ $l }}</div>
  </div>
  @endforeach
</div>

<div class="bg-gray-900 border border-gray-800 rounded-xl overflow-hidden">
  <div class="px-5 py-3 border-b border-gray-800 flex items-center justify-between">
    <span class="text-sm font-semibold">Pointage du {{ $date->translatedFormat('l d F Y') }}</span>
    <a href="{{ route('pointage.rapport', ['annee'=>$date->year,'mois'=>$date->month]) }}" class="text-xs text-blue-400 hover:text-blue-300">Rapport mensuel →</a>
  </div>
  <table class="w-full text-sm">
    <thead class="bg-gray-800"><tr>
      @foreach(['Salarié','Chantier','Entrée','Sortie','Durée','H. Supp.','Retard','Statut']) 
      <th class="px-4 py-3 text-left text-xs font-semibold text-gray-400 uppercase tracking-wider">{{ $h }}</th>
      @endforeach
    </tr></thead>
    <tbody class="divide-y divide-gray-800">
      @forelse($pointages as $p)
      <tr class="hover:bg-gray-800/40">
        <td class="px-4 py-3">
          <div class="flex items-center gap-2">
            <div class="w-7 h-7 rounded-lg bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-xs font-bold">{{ strtoupper(substr($p->salarie->prenom,0,1).substr($p->salarie->nom,0,1)) }}</div>
            <span class="font-medium text-gray-200">{{ $p->salarie->nom_complet }}</span>
          </div>
        </td>
        <td class="px-4 py-3 text-xs text-gray-400">{{ $p->salarie->chantier?->nom ?? '—' }}</td>
        <td class="px-4 py-3 font-mono text-sm {{ $p->heure_entree ? 'text-emerald-400' : 'text-gray-600' }}">{{ $p->heure_entree ?? '—' }}</td>
        <td class="px-4 py-3 font-mono text-sm text-gray-400">{{ $p->heure_sortie ?? '—' }}</td>
        <td class="px-4 py-3 text-gray-300">{{ $p->duree }}</td>
        <td class="px-4 py-3 {{ $p->heures_supplementaires > 0 ? 'text-amber-400' : 'text-gray-600' }}">{{ $p->heures_supplementaires > 0 ? '+'.$p->heures_supplementaires.'m' : '—' }}</td>
        <td class="px-4 py-3 {{ $p->minutes_retard > 0 ? 'text-red-400' : 'text-gray-600' }}">{{ $p->minutes_retard > 0 ? $p->minutes_retard.'min' : '—' }}</td>
        <td class="px-4 py-3">
          @php $sc=['present'=>'bg-emerald-500/10 text-emerald-400','absent'=>'bg-red-500/10 text-red-400','conge'=>'bg-blue-500/10 text-blue-400','jour_ferie'=>'bg-gray-500/10 text-gray-400'][$p->statut]??''; @endphp
          <span class="px-2 py-0.5 rounded-full text-xs {{ $sc }}">{{ ucfirst($p->statut) }}</span>
        </td>
      </tr>
      @empty
      <tr><td colspan="8" class="px-4 py-8 text-center text-gray-600">Aucun pointage pour cette date</td></tr>
      @endforelse
    </tbody>
  </table>
</div>

{{-- Modal pointage manuel --}}
<div id="modalPointage" class="hidden fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
  <div class="bg-gray-900 border border-gray-800 rounded-2xl w-full max-w-md">
    <div class="flex items-center justify-between p-5 border-b border-gray-800">
      <h3 class="font-semibold">Pointage manuel</h3>
      <button onclick="document.getElementById('modalPointage').classList.add('hidden')" class="w-8 h-8 rounded-lg bg-gray-800 text-gray-400 hover:text-gray-200">✕</button>
    </div>
    <form method="POST" action="{{ route('pointage.store') }}" class="p-5 space-y-3">
      @csrf
      <div><label class="text-xs text-gray-400 block mb-1">Salarié</label>
        <select name="salarie_id" required class="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-gray-300 outline-none focus:border-blue-500">
          @foreach(\App\Models\Salarie::actif()->orderBy('nom')->get() as $s)
          <option value="{{ $s->id }}">{{ $s->nom_complet }}</option>
          @endforeach
        </select>
      </div>
      <div class="grid grid-cols-2 gap-3">
        <div><label class="text-xs text-gray-400 block mb-1">Date</label>
          <input type="date" name="date" value="{{ now()->format('Y-m-d') }}" required class="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-gray-300 outline-none focus:border-blue-500">
        </div>
        <div><label class="text-xs text-gray-400 block mb-1">Statut</label>
          <select name="statut" required class="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-gray-300 outline-none focus:border-blue-500">
            @foreach(['present'=>'Présent','absent'=>'Absent','conge'=>'Congé','jour_ferie'=>'Jour férié'] as $v=>$l)
            <option value="{{ $v }}">{{ $l }}</option>
            @endforeach
          </select>
        </div>
        <div><label class="text-xs text-gray-400 block mb-1">Heure entrée</label>
          <input type="time" name="heure_entree" class="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-gray-300 outline-none focus:border-blue-500">
        </div>
        <div><label class="text-xs text-gray-400 block mb-1">Heure sortie</label>
          <input type="time" name="heure_sortie" class="w-full bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-gray-300 outline-none focus:border-blue-500">
        </div>
      </div>
      <div class="flex gap-2 justify-end pt-1">
        <button type="button" onclick="document.getElementById('modalPointage').classList.add('hidden')" class="px-4 py-2 bg-gray-800 text-gray-300 text-sm rounded-lg">Annuler</button>
        <button type="submit" class="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-sm font-medium rounded-lg">Enregistrer</button>
      </div>
    </form>
  </div>
</div>
@endsection
