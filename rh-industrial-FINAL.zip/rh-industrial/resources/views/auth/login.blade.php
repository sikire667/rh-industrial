<!doctype html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Connexion - RH Industrial Pro</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center p-6">
    <form method="POST" action="{{ route('login.store') }}" class="w-full max-w-md bg-slate-900 border border-slate-800 rounded-2xl p-8 shadow-xl">
        @csrf
        <h1 class="text-2xl font-bold mb-1">RH Industrial Pro</h1>
        <p class="text-slate-400 mb-6">Connexion à l’espace RH</p>

        @if ($errors->any())
            <div class="mb-4 rounded-lg bg-red-950 border border-red-800 text-red-200 p-3 text-sm">
                {{ $errors->first() }}
            </div>
        @endif

        <label class="block text-sm mb-2">Email</label>
        <input name="email" type="email" value="{{ old('email', 'admin@rh-industrial.ma') }}" required autofocus class="w-full mb-4 rounded-lg bg-slate-800 border border-slate-700 p-3">

        <label class="block text-sm mb-2">Mot de passe</label>
        <input name="password" type="password" value="password" required class="w-full mb-4 rounded-lg bg-slate-800 border border-slate-700 p-3">

        <label class="flex items-center gap-2 text-sm text-slate-300 mb-6">
            <input type="checkbox" name="remember" class="rounded bg-slate-800 border-slate-700"> Se souvenir de moi
        </label>

        <button class="w-full rounded-lg bg-blue-600 hover:bg-blue-500 p-3 font-semibold">Se connecter</button>

        <div class="mt-6 text-xs text-slate-400">
            Compte démo : admin@rh-industrial.ma / password
        </div>
    </form>
</body>
</html>
