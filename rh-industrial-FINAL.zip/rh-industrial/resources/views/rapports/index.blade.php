@extends('layouts.app')
@section('title','Rapports')
@section('page_title','Rapports & Exports')
@section('content')
<div class="grid grid-cols-3 gap-4">
  @foreach([
    ['Rapport de présence','Présences, absences, retards par période','fa-calendar-check','rapports.presence','text-blue-400','bg-blue-500/10'],
    ['Rapport d\'absence','Taux absentéisme et détail par salarié','fa-calendar-xmark','rapports.absence','text-amber-400','bg-amber-500/10'],
    ['Rapport disciplinaire','Sanctions et avertissements','fa-gavel','rapports.discipline','text-red-400','bg-red-500/10'],
    ['Rapport d\'évaluation','Notes et évolutions du personnel','fa-star','rapports.evaluation','text-yellow-400','bg-yellow-500/10'],
    ['Rapport de formation','Habilitations et certifications','fa-graduation-cap','rapports.formation','text-emerald-400','bg-emerald-500/10'],
    ['Rapport effectif','Mouvements, entrées, sorties','fa-users','rapports.presence','text-purple-400','bg-purple-500/10'],
  ] as [$titre,$desc,$icon,$route,$tc,$bg])
  <div class="bg-gray-900 border border-gray-800 rounded-xl p-5 hover:border-gray-700 transition-colors">
    <div class="w-11 h-11 rounded-xl {{ $bg }} {{ $tc }} flex items-center justify-center text-lg mb-4">
      <i class="fas {{ $icon }}"></i>
    </div>
    <div class="font-semibold mb-1">{{ $titre }}</div>
    <div class="text-sm text-gray-500 mb-4">{{ $desc }}</div>
    <div class="flex gap-2">
      <a href="{{ route($route, ['format'=>'web']) }}" class="flex-1 py-1.5 text-center text-xs bg-gray-800 hover:bg-gray-700 text-gray-300 rounded-lg border border-gray-700">Voir</a>
      <a href="{{ route($route, ['format'=>'excel']) }}" class="px-3 py-1.5 text-xs bg-emerald-900/50 hover:bg-emerald-700 text-emerald-400 rounded-lg border border-emerald-700/30">📊 Excel</a>
      <a href="{{ route($route, ['format'=>'pdf']) }}" class="px-3 py-1.5 text-xs bg-red-900/50 hover:bg-red-700 text-red-400 rounded-lg border border-red-700/30">📄 PDF</a>
    </div>
  </div>
  @endforeach
</div>
@endsection
