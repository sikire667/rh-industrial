import './bootstrap';

// Recherche globale
const searchInput = document.getElementById('globalSearch');
if (searchInput) {
    let timeout;
    searchInput.addEventListener('input', (e) => {
        clearTimeout(timeout);
        timeout = setTimeout(() => {
            const q = e.target.value.trim();
            if (q.length >= 2) {
                window.location.href = `/salaries?search=${encodeURIComponent(q)}`;
            }
        }, 400);
    });
}

// Auto-fermeture alertes flash
setTimeout(() => {
    document.querySelectorAll('.flash-alert').forEach(el => {
        el.style.transition = 'opacity .5s';
        el.style.opacity = '0';
        setTimeout(() => el.remove(), 500);
    });
}, 4000);
