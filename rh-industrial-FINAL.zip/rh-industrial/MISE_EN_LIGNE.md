# 🚀 GUIDE MISE EN LIGNE — RH Industrial Pro
# ================================================
# 3 options selon votre hébergeur

## ══════════════════════════════════════════
## OPTION A — Hébergement cPanel (Hostinger, OVH, Infomaniak...)
## ══════════════════════════════════════════

### ÉTAPE 1 — Créer la base de données
1. Connectez-vous à cPanel
2. Allez dans "Bases de données MySQL"
3. Créez une base : rh_industrial
4. Créez un utilisateur et un mot de passe
5. Donnez TOUS les privilèges à l'utilisateur sur cette base

### ÉTAPE 2 — Uploader les fichiers
1. Allez dans "Gestionnaire de fichiers" → dossier public_html
2. Uploadez TOUT le contenu du dossier rh-industrial/
   (glisser-déposer le ZIP puis extraire)

### ÉTAPE 3 — Configurer le .env
Dans le Gestionnaire de fichiers, éditez le fichier .env :
   APP_URL=https://votre-domaine.com
   DB_HOST=localhost
   DB_DATABASE=rh_industrial
   DB_USERNAME=votre_user
   DB_PASSWORD=votre_mot_de_passe
   APP_DEBUG=false

### ÉTAPE 4 — Terminal SSH (depuis cPanel → Terminal)
cd public_html/rh-industrial
bash deployer.sh

### ÉTAPE 5 — CRON (alertes automatiques)
Dans cPanel → Tâches planifiées, ajoutez :
   * * * * * cd /home/USER/public_html/rh-industrial && php artisan schedule:run


## ══════════════════════════════════════════
## OPTION B — VPS (DigitalOcean, Vultr, Contabo...)
## ══════════════════════════════════════════

# Connexion SSH
ssh root@IP_SERVEUR

# Installation rapide (Ubuntu 22/24)
apt update && apt install -y php8.2 php8.2-cli php8.2-fpm php8.2-mysql \
  php8.2-zip php8.2-gd php8.2-mbstring php8.2-curl php8.2-xml \
  mysql-server nginx composer nodejs npm unzip

# Créer la base
mysql -u root -e "CREATE DATABASE rh_industrial; CREATE USER 'rh_user'@'localhost' IDENTIFIED BY 'motdepasse'; GRANT ALL ON rh_industrial.* TO 'rh_user'@'localhost';"

# Uploader et déployer
cd /var/www
scp -r rh-industrial/ root@IP:/var/www/
cd rh-industrial
bash deployer.sh

# Config Nginx
cat > /etc/nginx/sites-available/rh-industrial << 'NGINX'
server {
    listen 80;
    server_name votre-domaine.com;
    root /var/www/rh-industrial/public;
    index index.php;
    location / { try_files $uri $uri/ /index.php?$query_string; }
    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.2-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $realpath_root$fastcgi_script_name;
        include fastcgi_params;
    }
}
NGINX
ln -s /etc/nginx/sites-available/rh-industrial /etc/nginx/sites-enabled/
nginx -t && systemctl reload nginx

# SSL gratuit (HTTPS)
apt install -y certbot python3-certbot-nginx
certbot --nginx -d votre-domaine.com


## ══════════════════════════════════════════
## OPTION C — Railway / Render (gratuit, sans serveur)
## ══════════════════════════════════════════

1. Créez un compte sur railway.app
2. New Project → Deploy from GitHub
   (uploadez d'abord le code sur GitHub)
3. Add Plugin → MySQL
4. Copiez les variables DB dans les variables d'environnement
5. Ajoutez : APP_KEY, APP_ENV=production, APP_URL
6. Deploy → l'application se lance automatiquement


## ══════════════════════════════════════════
## APRÈS L'INSTALLATION — Sécurité
## ══════════════════════════════════════════

⚠  OBLIGATOIRE après la mise en ligne :

1. Changez le mot de passe admin :
   Connectez-vous avec admin@rh-industrial.ma / password
   Allez dans Paramètres → Changer le mot de passe

2. Vérifiez que APP_DEBUG=false dans .env

3. Activez le CRON pour les alertes automatiques

## Comptes par défaut
   Admin   : admin@rh-industrial.ma  / password
   RH      : rh@rh-industrial.ma     / password
