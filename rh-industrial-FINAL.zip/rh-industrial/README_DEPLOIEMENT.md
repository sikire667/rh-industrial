# RH Industrial Pro — Déploiement

## Installation locale

```bash
composer install
copy .env.example .env
php artisan key:generate
php artisan migrate:fresh --seed
npm install
npm run build
php artisan serve
```

Connexion démo :

- Email : `admin@rh-industrial.ma`
- Mot de passe : `password`

## Mise en ligne hébergement mutualisé

1. Envoyer tous les fichiers sur l'hébergement.
2. Pointer le domaine vers le dossier `public/`.
3. Créer une base MySQL.
4. Modifier `.env` :

```env
APP_ENV=production
APP_DEBUG=false
APP_URL=https://votre-domaine.com
DB_DATABASE=nom_base
DB_USERNAME=utilisateur_base
DB_PASSWORD=mot_de_passe
```

5. Lancer via SSH :

```bash
composer install --no-dev --optimize-autoloader
php artisan key:generate
php artisan migrate --seed
php artisan storage:link
php artisan config:cache
php artisan route:cache
php artisan view:cache
```

## Notes

Ce ZIP corrige la structure Laravel manquante : `artisan`, `public/`, `bootstrap/`, routes d'authentification, modèle `User`, migrations système et vues minimales manquantes.
Certaines vues détaillées restent des pages provisoires à finaliser.
