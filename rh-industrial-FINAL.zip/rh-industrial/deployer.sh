#!/usr/bin/env bash
# ══════════════════════════════════════════════════════
#   RH Industrial Pro — Script de déploiement serveur
#   À exécuter UNE SEULE FOIS sur le serveur via SSH
# ══════════════════════════════════════════════════════
set -e
GREEN="\033[1;32m"; BLUE="\033[1;34m"; YELLOW="\033[1;33m"; RED="\033[1;31m"; NC="\033[0m"
info() { echo -e "${BLUE}▶  $1${NC}"; }
ok()   { echo -e "${GREEN}✅ $1${NC}"; }
warn() { echo -e "${YELLOW}⚠  $1${NC}"; }
err()  { echo -e "${RED}❌ $1${NC}"; exit 1; }

clear
echo -e "${GREEN}"
echo "  ╔══════════════════════════════════════════════╗"
echo "  ║   RH Industrial Pro — Déploiement Serveur   ║"
echo "  ╚══════════════════════════════════════════════╝"
echo -e "${NC}"

[ ! -f "composer.json" ] && err "Lancez ce script depuis le dossier rh-industrial"

# ── Info serveur ────────────────────────────────────
info "Informations de déploiement"
echo -n "  Votre domaine (ex: rh.monentreprise.ma) : "; read APP_URL
echo -n "  Hôte MySQL [localhost] : ";                  read DB_HOST;  DB_HOST=${DB_HOST:-localhost}
echo -n "  Nom de la base de données : ";               read DB_NAME
echo -n "  Utilisateur MySQL : ";                       read DB_USER
echo -n "  Mot de passe MySQL : ";                      read -s DB_PASS; echo

# ── .env production ─────────────────────────────────
info "Configuration .env production..."
cp .env.production .env
sed -i "s|https://VOTRE-DOMAINE.COM|https://${APP_URL}|" .env
sed -i "s|VOTRE_BDD|${DB_NAME}|"           .env
sed -i "s|VOTRE_USER_BDD|${DB_USER}|"      .env
sed -i "s|VOTRE_MOT_DE_PASSE|${DB_PASS}|"  .env
ok ".env configuré"

# ── Dépendances production ───────────────────────────
info "Installation des dépendances (production)..."
composer install --no-dev --no-interaction --prefer-dist --optimize-autoloader
ok "Composer OK"

# ── Clé application ──────────────────────────────────
php artisan key:generate --ansi
ok "Clé générée"

# ── Base de données ──────────────────────────────────
info "Migration + données de démo..."
php artisan migrate --seed --force
ok "Base de données prête"

# ── Assets (si node dispo) ───────────────────────────
if command -v npm &>/dev/null; then
    info "Compilation assets..."
    npm ci && npm run build
    ok "Assets compilés"
else
    warn "npm non disponible — uploadez le dossier public/build depuis votre PC"
fi

# ── Optimisation production ──────────────────────────
info "Optimisation Laravel..."
php artisan config:cache
php artisan route:cache
php artisan view:cache
php artisan optimize
ok "Cache optimisé"

# ── Storage ──────────────────────────────────────────
php artisan storage:link 2>/dev/null || true
chmod -R 775 storage bootstrap/cache
ok "Permissions OK"

# ── .htaccess racine ────────────────────────────────
cat > .htaccess << 'HTA'
<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteRule ^(.*)$ public/$1 [L]
</IfModule>
HTA
ok ".htaccess racine créé"

# ── CRON ────────────────────────────────────────────
CRON_CMD="* * * * * cd $(pwd) && php artisan schedule:run >> /dev/null 2>&1"
echo ""
warn "Ajoutez cette ligne dans votre CRON (cPanel → Tâches planifiées) :"
echo -e "  ${YELLOW}${CRON_CMD}${NC}"

echo ""
echo -e "${GREEN}"
echo "  ╔══════════════════════════════════════════════╗"
echo "  ║        ✅  Déploiement terminé !             ║"
echo "  ╠══════════════════════════════════════════════╣"
echo "  ║  URL     : https://${APP_URL}"
echo "  ║  Email   : admin@rh-industrial.ma            ║"
echo "  ║  Pass    : password  ← CHANGEZ-LE !          ║"
echo "  ╚══════════════════════════════════════════════╝"
echo -e "${NC}"
