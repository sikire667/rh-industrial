<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\{
    DashboardController, SalarieController, AbsenceController,
    PointageController, DocumentController, EvaluationController,
    FormationController, EpiController, DisciplineController,
    RapportController, CorbeilleController, HistoriqueController
};

Route::middleware(['auth'])->group(function () {

    // Dashboard
    Route::get('/', [DashboardController::class, 'index'])->name('dashboard');

    // Salariés
    Route::resource('salaries', SalarieController::class);

    // Absences
    Route::get('absences', [AbsenceController::class, 'index'])->name('absences.index');
    Route::post('absences', [AbsenceController::class, 'store'])->name('absences.store');
    Route::patch('absences/{absence}/valider', [AbsenceController::class, 'valider'])->name('absences.valider');
    Route::patch('absences/{absence}/refuser', [AbsenceController::class, 'refuser'])->name('absences.refuser');
    Route::delete('absences/{absence}', [AbsenceController::class, 'destroy'])->name('absences.destroy');

    // Pointage
    Route::get('pointage', [PointageController::class, 'index'])->name('pointage.index');
    Route::post('pointage', [PointageController::class, 'store'])->name('pointage.store');
    Route::get('pointage/rapport', [PointageController::class, 'rapportMensuel'])->name('pointage.rapport');

    // Documents
    Route::get('documents', [DocumentController::class, 'index'])->name('documents.index');
    Route::post('documents', [DocumentController::class, 'store'])->name('documents.store');
    Route::get('documents/{document}/download', [DocumentController::class, 'download'])->name('documents.download');
    Route::delete('documents/{document}', [DocumentController::class, 'destroy'])->name('documents.destroy');

    // Évaluations
    Route::get('evaluations', [EvaluationController::class, 'index'])->name('evaluations.index');
    Route::post('evaluations', [EvaluationController::class, 'store'])->name('evaluations.store');
    Route::get('evaluations/{salarie}/evolution', [EvaluationController::class, 'evolution'])->name('evaluations.evolution');

    // Formations
    Route::get('formations', [FormationController::class, 'index'])->name('formations.index');
    Route::post('formations', [FormationController::class, 'store'])->name('formations.store');

    // EPI
    Route::get('epi', [EpiController::class, 'index'])->name('epi.index');
    Route::post('epi/distribuer', [EpiController::class, 'distribuer'])->name('epi.distribuer');

    // Disciplinaire
    Route::get('disciplines', [DisciplineController::class, 'index'])->name('disciplines.index');
    Route::post('disciplines', [DisciplineController::class, 'store'])->name('disciplines.store');
    Route::patch('disciplines/{mesure}/cloture', [DisciplineController::class, 'cloture'])->name('disciplines.cloture');

    // Rapports
    Route::get('rapports', [RapportController::class, 'index'])->name('rapports.index');
    Route::get('rapports/presence', [RapportController::class, 'presence'])->name('rapports.presence');
    Route::get('rapports/absence', [RapportController::class, 'absence'])->name('rapports.absence');
    Route::get('rapports/discipline', [RapportController::class, 'discipline'])->name('rapports.discipline');
    Route::get('rapports/evaluation', [RapportController::class, 'evaluation'])->name('rapports.evaluation');
    Route::get('rapports/formation', [RapportController::class, 'formation'])->name('rapports.formation');

    // Historique
    Route::get('historique', [HistoriqueController::class, 'index'])->name('historique.index');

    // Corbeille (admin only)
    Route::get('corbeille', [CorbeilleController::class, 'index'])->name('corbeille.index');
    Route::post('corbeille/restaurer', [CorbeilleController::class, 'restaurer'])->name('corbeille.restaurer');
    Route::delete('corbeille/supprimer', [CorbeilleController::class, 'supprimerDefinitivement'])->name('corbeille.supprimer');
});

require __DIR__.'/auth.php';
