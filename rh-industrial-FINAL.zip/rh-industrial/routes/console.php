<?php

use Illuminate\Support\Facades\Artisan;

Artisan::command('app:verifier-alertes', function () {
    $this->call(App\Console\Commands\VerifierAlertes::class);
})->purpose('Vérifier les alertes RH');
