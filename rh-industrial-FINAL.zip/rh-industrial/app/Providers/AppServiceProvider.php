<?php

namespace App\Providers;

use App\Models\Salarie;
use App\Observers\SalarieObserver;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        Salarie::observe(SalarieObserver::class);
    }
}
