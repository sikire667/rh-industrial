<?php
namespace App\Console\Commands;
use Illuminate\Console\Command;
use App\Services\AlerteService;
use App\Models\{SalarieFormation, Document};
use Carbon\Carbon;

class VerifierAlertes extends Command
{
    protected $signature   = 'rh:alertes';
    protected $description = 'Vérifier et envoyer les alertes d\'expiration RH';

    public function handle(AlerteService $service): void
    {
        $this->info("🔍 Vérification des alertes — " . now()->format('d/m/Y H:i'));

        // Mettre à jour statuts formations
        SalarieFormation::whereNotNull('date_expiration')->each(fn($f) => $f->rafraichirStatut());
        $this->info("✅ Statuts formations mis à jour");

        // Alertes documents
        $docs = $service->documentsExpires(30);
        $this->info("📄 Documents : " . count($docs) . " alerte(s)");
        foreach ($docs as $a) {
            $this->line("  [{$a['niveau']}] {$a['message']} ({$a['jours']} jours)");
        }

        // Alertes formations
        $forms = $service->formationsExpirees(60);
        $this->info("🎓 Formations : " . count($forms) . " alerte(s)");
        foreach ($forms as $a) {
            $this->line("  [{$a['niveau']}] {$a['message']}");
        }

        // Alertes EPI
        $epis = $service->stockEpiFaible();
        $this->info("🦺 EPI stock : " . count($epis) . " alerte(s)");

        // Contrats
        $contrats = $service->contratsExpirant(30);
        $this->info("📋 Contrats : " . count($contrats) . " alerte(s)");

        $total = count($docs) + count($forms) + count($epis) + count($contrats);
        $this->info("──────────────────────────────────");
        $this->info("Total alertes actives : {$total}");
    }
}
