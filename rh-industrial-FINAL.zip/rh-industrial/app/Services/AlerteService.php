<?php
namespace App\Services;
use App\Models\{Document, SalarieFormation, Epi, Salarie};
use Carbon\Carbon;

class AlerteService
{
    public function documentsExpires(int $joursAvant = 30): array
    {
        return Document::with('salarie')
            ->whereNotNull('date_expiration')
            ->where('date_expiration', '<=', Carbon::now()->addDays($joursAvant))
            ->get()
            ->map(fn($d) => [
                'niveau'   => $d->date_expiration->isPast() ? 'danger' : 'warning',
                'message'  => "[{$d->type}] {$d->titre} — {$d->salarie->nom_complet}",
                'jours'    => (int) Carbon::now()->diffInDays($d->date_expiration, false),
                'salarie'  => $d->salarie->nom_complet,
            ])
            ->toArray();
    }

    public function formationsExpirees(int $joursAvant = 60): array
    {
        return SalarieFormation::with(['salarie','formation'])
            ->whereNotNull('date_expiration')
            ->where('date_expiration', '<=', Carbon::now()->addDays($joursAvant))
            ->get()
            ->map(fn($f) => [
                'niveau'   => $f->date_expiration->isPast() ? 'danger' : 'warning',
                'message'  => "[{$f->formation->type}] {$f->formation->titre} — {$f->salarie->nom_complet}",
                'jours'    => (int) Carbon::now()->diffInDays($f->date_expiration, false),
                'salarie'  => $f->salarie->nom_complet,
            ])
            ->toArray();
    }

    public function stockEpiFaible(): array
    {
        return Epi::all()
            ->filter(fn($e) => $e->stock_disponible <= $e->seuil_alerte)
            ->map(fn($e) => [
                'niveau'  => $e->stock_disponible == 0 ? 'danger' : 'warning',
                'message' => "Stock faible : {$e->designation} ({$e->stock_disponible} restants)",
                'stock'   => $e->stock_disponible,
            ])
            ->values()
            ->toArray();
    }

    public function contratsExpirant(int $joursAvant = 30): array
    {
        return Salarie::actif()
            ->whereNotNull('fin_contrat')
            ->where('fin_contrat', '<=', Carbon::now()->addDays($joursAvant))
            ->get()
            ->map(fn($s) => [
                'niveau'  => $s->fin_contrat->isPast() ? 'danger' : 'warning',
                'message' => "Contrat {$s->type_contrat} expirant — {$s->nom_complet}",
                'jours'   => (int) Carbon::now()->diffInDays($s->fin_contrat, false),
            ])
            ->toArray();
    }

    public function toutes(): array
    {
        return array_merge(
            $this->documentsExpires(),
            $this->formationsExpirees(),
            $this->stockEpiFaible(),
            $this->contratsExpirant()
        );
    }
}
