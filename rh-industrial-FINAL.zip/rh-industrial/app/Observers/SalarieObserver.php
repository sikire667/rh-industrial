<?php
namespace App\Observers;
use App\Models\{Salarie, AuditLog};

class SalarieObserver
{
    private array $original = [];

    public function retrieved(Salarie $salarie): void
    {
        $this->original[$salarie->id] = $salarie->toArray();
    }

    public function creating(Salarie $salarie): void
    {
        if (empty($salarie->matricule)) {
            $salarie->matricule = Salarie::nextMatricule();
        }
    }

    public function created(Salarie $salarie): void
    {
        AuditLog::journal('creation', 'salaries', $salarie, [], $salarie->toArray());
    }

    public function updated(Salarie $salarie): void
    {
        $dirty = $salarie->getDirty();
        if (!empty($dirty)) {
            AuditLog::journal('modification', 'salaries', $salarie,
                array_intersect_key($this->original[$salarie->id] ?? [], $dirty),
                $dirty
            );
        }
    }

    public function deleted(Salarie $salarie): void
    {
        AuditLog::journal('suppression_logique', 'salaries', $salarie, $salarie->toArray());
    }

    public function restored(Salarie $salarie): void
    {
        AuditLog::journal('restauration', 'salaries', $salarie);
    }

    public function forceDeleted(Salarie $salarie): void
    {
        AuditLog::journal('suppression_definitive', 'salaries', $salarie, $salarie->toArray());
    }
}
