<?php
namespace App\Http\Controllers;
use App\Models\{Salarie, Societe, Chantier, Fonction, AuditLog};
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class SalarieController extends Controller
{
    public function index(Request $request)
    {
        $query = Salarie::with(['fonction','chantier','societe'])
            ->when($request->search, fn($q) => $q->search($request->search))
            ->when($request->contrat, fn($q) => $q->parContrat($request->contrat))
            ->when($request->chantier_id, fn($q) => $q->parChantier($request->chantier_id))
            ->when($request->statut, fn($q) => $q->where('statut', $request->statut));

        $salaries  = $query->orderBy('nom')->paginate(15)->withQueryString();
        $chantiers = Chantier::where('statut', 'actif')->get();
        $stats = [
            'total'   => Salarie::actif()->count(),
            'cdi'     => Salarie::actif()->parContrat('CDI')->count(),
            'cdd'     => Salarie::actif()->parContrat('CDD')->count(),
            'interim' => Salarie::actif()->parContrat('Interim')->count(),
        ];
        return view('salaries.index', compact('salaries','chantiers','stats'));
    }

    public function create()
    {
        return view('salaries.create', [
            'societes'  => Societe::all(),
            'chantiers' => Chantier::where('statut', 'actif')->get(),
            'fonctions' => Fonction::orderBy('libelle')->get(),
            'matricule' => Salarie::nextMatricule(),
        ]);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'matricule'     => 'required|unique:salaries',
            'nom'           => 'required|string|max:100',
            'prenom'        => 'required|string|max:100',
            'cin'           => 'required|unique:salaries|max:20',
            'telephone'     => 'nullable|string|max:20',
            'adresse'       => 'nullable|string',
            'date_naissance'=> 'nullable|date',
            'date_embauche' => 'required|date',
            'fonction_id'   => 'nullable|exists:fonctions,id',
            'societe_id'    => 'required|exists:societes,id',
            'chantier_id'   => 'nullable|exists:chantiers,id',
            'type_contrat'  => 'required|in:CDI,CDD,Interim',
            'fin_contrat'   => 'nullable|date',
            'salaire_base'  => 'nullable|numeric',
            'photo'         => 'nullable|image|max:2048',
        ]);
        if ($request->hasFile('photo')) {
            $data['photo'] = $request->file('photo')->store('photos/salaries', 'public');
        }
        $salarie = Salarie::create($data);
        AuditLog::journal('creation', 'salaries', $salarie, [], $salarie->toArray());
        return redirect()->route('salaries.show', $salarie)->with('success', "Salarié {$salarie->nom_complet} créé.");
    }

    public function show(Salarie $salarie)
    {
        $salarie->load(['fonction','chantier','societe','documents','absences','pointages','evaluations.evaluateur','formations.formation','disciplines','epis.epi']);
        return view('salaries.show', compact('salarie'));
    }

    public function edit(Salarie $salarie)
    {
        return view('salaries.edit', [
            'salarie'   => $salarie,
            'societes'  => Societe::all(),
            'chantiers' => Chantier::where('statut', 'actif')->get(),
            'fonctions' => Fonction::orderBy('libelle')->get(),
        ]);
    }

    public function update(Request $request, Salarie $salarie)
    {
        $avant = $salarie->toArray();
        $data = $request->validate([
            'nom'           => 'required|string|max:100',
            'prenom'        => 'required|string|max:100',
            'cin'           => "required|max:20|unique:salaries,cin,{$salarie->id}",
            'telephone'     => 'nullable|string|max:20',
            'adresse'       => 'nullable|string',
            'date_embauche' => 'required|date',
            'fonction_id'   => 'nullable|exists:fonctions,id',
            'societe_id'    => 'required|exists:societes,id',
            'chantier_id'   => 'nullable|exists:chantiers,id',
            'type_contrat'  => 'required|in:CDI,CDD,Interim',
            'fin_contrat'   => 'nullable|date',
            'statut'        => 'required|in:actif,inactif,suspendu',
        ]);
        $salarie->update($data);
        AuditLog::journal('modification', 'salaries', $salarie, $avant, $salarie->fresh()->toArray());
        return redirect()->route('salaries.show', $salarie)->with('success', 'Fiche mise à jour.');
    }

    public function destroy(Salarie $salarie)
    {
        AuditLog::journal('suppression', 'salaries', $salarie, $salarie->toArray());
        $salarie->delete();
        return redirect()->route('salaries.index')->with('success', 'Salarié archivé.');
    }
}
