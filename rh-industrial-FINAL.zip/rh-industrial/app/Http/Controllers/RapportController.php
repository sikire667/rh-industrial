<?php
namespace App\Http\Controllers;
use App\Models\{Salarie, Absence, Pointage, Evaluation, SalarieFormation, MesureDisciplinaire};
use Illuminate\Http\Request;

class RapportController extends Controller
{
    public function index() { return view('rapports.index'); }

    public function presence(Request $request)
    {
        $annee = $request->annee ?? now()->year;
        $mois  = $request->mois  ?? now()->month;
        $data = Salarie::actif()->with(['pointages' => fn($q) => $q->whereYear('date',$annee)->whereMonth('date',$mois)])->get()
            ->map(fn($s) => [
                'matricule'      => $s->matricule,
                'nom'            => $s->nom_complet,
                'chantier'       => $s->chantier?->nom ?? '—',
                'jours_presents' => $s->pointages->where('statut','present')->count(),
                'jours_absents'  => $s->pointages->where('statut','absent')->count(),
                'retards'        => $s->pointages->where('minutes_retard','>',0)->count(),
                'heures_sup'     => $s->pointages->sum('heures_supplementaires'),
            ]);
        return view('rapports.presence', compact('data','annee','mois'));
    }

    public function absence(Request $request)
    {
        $annee = $request->annee ?? now()->year;
        $mois  = $request->mois  ?? now()->month;
        $data = Absence::with('salarie')->whereYear('date_debut',$annee)->whereMonth('date_debut',$mois)->get();
        return view('rapports.absence', compact('data','annee','mois'));
    }

    public function discipline(Request $request)
    {
        $data = MesureDisciplinaire::with(['salarie','emisPar'])
            ->when($request->annee, fn($q) => $q->whereYear('date',$request->annee))
            ->orderByDesc('date')->get();
        return view('rapports.discipline', compact('data'));
    }

    public function evaluation(Request $request)
    {
        $data = Evaluation::with(['salarie','evaluateur'])
            ->when($request->annee, fn($q) => $q->where('annee',$request->annee))
            ->when($request->periode, fn($q) => $q->where('periode',$request->periode))
            ->orderByDesc('annee')->get();
        return view('rapports.evaluation', compact('data'));
    }

    public function formation(Request $request)
    {
        $data = SalarieFormation::with(['salarie','formation'])
            ->when($request->statut, fn($q) => $q->where('statut',$request->statut))
            ->orderBy('date_expiration')->get();
        return view('rapports.formation', compact('data'));
    }
}
