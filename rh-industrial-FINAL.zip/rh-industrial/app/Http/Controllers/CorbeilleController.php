<?php
namespace App\Http\Controllers;
use App\Models\{Salarie, Document, MesureDisciplinaire, AuditLog};
use Illuminate\Http\Request;

class CorbeilleController extends Controller
{
    public function index()
    {
        $salaries    = Salarie::onlyTrashed()->get();
        $documents   = Document::onlyTrashed()->with('salarie')->get();
        $disciplines = MesureDisciplinaire::onlyTrashed()->with('salarie')->get();
        return view('corbeille.index', compact('salaries','documents','disciplines'));
    }

    public function restaurer(Request $request)
    {
        $model = $this->resolveModel($request->type, $request->id);
        $model->restore();
        AuditLog::journal('restauration', $request->type, $model);
        return back()->with('success', 'Élément restauré.');
    }

    public function supprimerDefinitivement(Request $request)
    {
        $model = $this->resolveModel($request->type, $request->id, true);
        AuditLog::journal('suppression_definitive', $request->type, $model, $model->toArray());
        $model->forceDelete();
        return back()->with('success', 'Supprimé définitivement.');
    }

    private function resolveModel(string $type, int $id, bool $onlyTrashed = true)
    {
        $map = ['salaries' => Salarie::class, 'documents' => Document::class, 'disciplines' => MesureDisciplinaire::class];
        $class = $map[$type] ?? abort(404);
        return $onlyTrashed ? $class::onlyTrashed()->findOrFail($id) : $class::withTrashed()->findOrFail($id);
    }
}
