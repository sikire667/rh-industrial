<?php
namespace App\Http\Controllers;
use App\Models\{Pointage, Salarie, AuditLog};
use Illuminate\Http\Request;
use Carbon\Carbon;

class PointageController extends Controller
{
    public function index(Request $request)
    {
        $date = $request->date ? Carbon::parse($request->date) : Carbon::today();
        $pointages = Pointage::with('salarie.chantier')
            ->where('date', $date)
            ->when($request->chantier_id, fn($q) => $q->whereHas('salarie', fn($s) => $s->where('chantier_id', $request->chantier_id)))
            ->get();
        $stats = [
            'presents'     => $pointages->where('statut','present')->count(),
            'absents'      => $pointages->where('statut','absent')->count(),
            'retards'      => $pointages->where('minutes_retard','>',0)->count(),
            'heures_sup'   => $pointages->sum('heures_supplementaires'),
            'total_minutes'=> $pointages->sum('minutes_travailles'),
        ];
        return view('pointage.index', compact('pointages','date','stats'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'salarie_id'   => 'required|exists:salaries,id',
            'date'         => 'required|date',
            'heure_entree' => 'nullable|date_format:H:i',
            'heure_sortie' => 'nullable|date_format:H:i',
            'statut'       => 'required|in:present,absent,conge,jour_ferie',
            'notes'        => 'nullable|string',
        ]);
        if (!empty($data['heure_entree']) && !empty($data['heure_sortie'])) {
            $entree = Carbon::parse($data['heure_entree']);
            $sortie = Carbon::parse($data['heure_sortie']);
            $data['minutes_travailles']       = $entree->diffInMinutes($sortie);
            $data['heures_supplementaires']   = max(0, $data['minutes_travailles'] - 480);
            $data['minutes_retard']           = max(0, (int)Carbon::parse('08:00')->diffInMinutes($entree, false) * -1);
        }
        $pointage = Pointage::updateOrCreate(
            ['salarie_id' => $data['salarie_id'], 'date' => $data['date']],
            $data
        );
        AuditLog::journal('pointage', 'pointages', $pointage, [], $pointage->toArray());
        return back()->with('success', 'Pointage enregistré.');
    }

    public function rapportMensuel(Request $request)
    {
        $annee   = $request->annee ?? now()->year;
        $mois    = $request->mois  ?? now()->month;
        $rapport = Pointage::rapportMensuel($annee, $mois, $request->chantier_id);
        return view('pointage.rapport', compact('rapport','annee','mois'));
    }
}
