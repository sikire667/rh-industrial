<?php

namespace App\Http\Controllers;

abstract class Controller
{
    // Contrôleur de base Laravel.
}
