<?php
namespace App\Http\Controllers;
use App\Models\{Salarie, Absence, Pointage, Document, SalarieFormation, Epi, AuditLog, Chantier};
use Illuminate\Http\Request;
use Carbon\Carbon;

class DashboardController extends Controller
{
    public function index()
    {
        $aujourd_hui = Carbon::today();
        $mois = $aujourd_hui->month;
        $annee = $aujourd_hui->year;

        $kpis = [
            'effectif_total'   => Salarie::actif()->count(),
            'presents_today'   => Pointage::where('date', $aujourd_hui)->where('statut', 'present')->count(),
            'absents_today'    => Pointage::where('date', $aujourd_hui)->where('statut', 'absent')->count(),
            'interimaires'     => Salarie::actif()->parContrat('Interim')->count(),
            'docs_expires'     => Document::expires()->count(),
            'docs_bientot'     => Document::bientotExpires(30)->count(),
            'formations_exp'   => SalarieFormation::expires()->count(),
            'alertes_total'    => Document::expires()->count() + SalarieFormation::expires()->count(),
            'taux_absenteisme' => Absence::tauxAbsenteisme($annee, $mois),
        ];

        $presences30j = collect(range(29, 0))->map(function ($j) {
            $date = Carbon::today()->subDays($j);
            return [
                'date'     => $date->format('d/m'),
                'presents' => Pointage::where('date', $date)->where('statut', 'present')->count(),
                'absents'  => Pointage::where('date', $date)->where('statut', 'absent')->count(),
            ];
        });

        $parChantier = Chantier::withCount(['salaries' => fn($q) => $q->actif()])
            ->where('statut', 'actif')->get()
            ->map(fn($c) => ['nom' => $c->nom, 'effectif' => $c->salaries_count]);

        $parContrat = Salarie::actif()->selectRaw('type_contrat, count(*) as total')
            ->groupBy('type_contrat')->pluck('total', 'type_contrat');

        $alertes = [];
        Document::with('salarie')->expires()->limit(5)->get()->each(function ($d) use (&$alertes) {
            $alertes[] = ['type' => 'danger', 'msg' => "Document expiré ({$d->type}) — {$d->salarie->nom_complet}", 'jours' => $d->jours_restants];
        });
        SalarieFormation::with(['salarie','formation'])->expires()->limit(5)->get()->each(function ($f) use (&$alertes) {
            $alertes[] = ['type' => 'danger', 'msg' => "Formation expirée ({$f->formation->titre}) — {$f->salarie->nom_complet}", 'jours' => null];
        });

        $activite = AuditLog::with('user')->latest()->limit(10)->get();

        $absenteisme6m = collect(range(5, 0))->map(function ($m) use ($annee, $mois) {
            $d = Carbon::create($annee, $mois)->subMonths($m);
            return ['mois' => $d->format('M'), 'taux' => Absence::tauxAbsenteisme($d->year, $d->month)];
        });

        return view('dashboard.index', compact('kpis','presences30j','parChantier','parContrat','alertes','activite','absenteisme6m'));
    }
}
