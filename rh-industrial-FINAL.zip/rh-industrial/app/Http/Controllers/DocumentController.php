<?php
namespace App\Http\Controllers;
use App\Models\{Document, Salarie, AuditLog};
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class DocumentController extends Controller
{
    public function index(Request $request)
    {
        $query = Document::with('salarie')
            ->when($request->type, fn($q) => $q->where('type', $request->type))
            ->when($request->statut === 'expire', fn($q) => $q->expires())
            ->when($request->statut === 'bientot', fn($q) => $q->bientotExpires())
            ->when($request->salarie_id, fn($q) => $q->where('salarie_id', $request->salarie_id));
        $documents = $query->orderBy('date_expiration')->paginate(20)->withQueryString();
        $stats = [
            'expires'    => Document::expires()->count(),
            'bientot_30j'=> Document::bientotExpires(30)->count(),
            'valides'    => Document::where(function($q){ $q->whereNull('date_expiration')->orWhere('date_expiration','>',now()->addDays(30)); })->count(),
            'total'      => Document::count(),
        ];
        return view('documents.index', compact('documents','stats'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'salarie_id'      => 'required|exists:salaries,id',
            'type'            => 'required|in:contrat,cin,diplome,certificat_medical,habilitation,permis,attestation,autre',
            'titre'           => 'required|string|max:200',
            'reference'       => 'nullable|string|max:100',
            'date_emission'   => 'nullable|date',
            'date_expiration' => 'nullable|date',
            'fichier'         => 'nullable|file|mimes:pdf,jpg,jpeg,png|max:10240',
            'notes'           => 'nullable|string',
        ]);
        if ($request->hasFile('fichier')) {
            $data['fichier'] = $request->file('fichier')->store('documents','public');
        }
        $doc = Document::create($data);
        AuditLog::journal('ajout_document', 'documents', $doc, [], $doc->toArray());
        return back()->with('success', 'Document ajouté.');
    }

    public function download(Document $document)
    {
        abort_unless($document->fichier && Storage::disk('public')->exists($document->fichier), 404);
        return Storage::disk('public')->download($document->fichier, $document->titre);
    }

    public function destroy(Document $document)
    {
        AuditLog::journal('suppression_document', 'documents', $document, $document->toArray());
        if ($document->fichier) Storage::disk('public')->delete($document->fichier);
        $document->delete();
        return back()->with('success', 'Document supprimé.');
    }
}
