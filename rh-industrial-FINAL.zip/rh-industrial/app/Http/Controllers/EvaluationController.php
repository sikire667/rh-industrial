<?php
namespace App\Http\Controllers;
use App\Models\{Evaluation, Salarie, AuditLog};
use Illuminate\Http\Request;

class EvaluationController extends Controller
{
    public function index(Request $request)
    {
        $evaluations = Evaluation::with(['salarie','evaluateur'])
            ->when($request->periode, fn($q) => $q->where('periode', $request->periode))
            ->when($request->annee,   fn($q) => $q->where('annee', $request->annee))
            ->orderByDesc('created_at')->paginate(20)->withQueryString();
        $stats = [
            'excellent'  => Evaluation::where('resultat','excellent')->whereYear('created_at', now()->year)->count(),
            'tres_bien'  => Evaluation::where('resultat','tres_bien')->whereYear('created_at', now()->year)->count(),
            'bien'       => Evaluation::where('resultat','bien')->whereYear('created_at', now()->year)->count(),
            'ameliorer'  => Evaluation::whereIn('resultat',['a_ameliorer','insuffisant'])->whereYear('created_at', now()->year)->count(),
            'moy_globale'=> round(Evaluation::whereYear('created_at', now()->year)->avg('note_globale'), 1),
        ];
        return view('evaluations.index', compact('evaluations','stats'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'salarie_id'           => 'required|exists:salaries,id',
            'periode'              => 'required|in:mensuel,trimestriel,annuel',
            'annee'                => 'required|digits:4',
            'trimestre'            => 'nullable|integer|between:1,4',
            'mois'                 => 'nullable|integer|between:1,12',
            'note_ponctualite'     => 'nullable|integer|between:1,5',
            'note_discipline'      => 'nullable|integer|between:1,5',
            'note_hse'             => 'nullable|integer|between:1,5',
            'note_qualite_travail' => 'nullable|integer|between:1,5',
            'note_productivite'    => 'nullable|integer|between:1,5',
            'note_esprit_equipe'   => 'nullable|integer|between:1,5',
            'note_comportement'    => 'nullable|integer|between:1,5',
            'commentaires'         => 'nullable|string',
        ]);
        $notes = array_filter([
            $data['note_ponctualite'] ?? null, $data['note_discipline'] ?? null,
            $data['note_hse'] ?? null, $data['note_qualite_travail'] ?? null,
            $data['note_productivite'] ?? null, $data['note_esprit_equipe'] ?? null,
            $data['note_comportement'] ?? null,
        ]);
        $data['note_globale']  = Evaluation::calculerNote($notes);
        $data['resultat']      = Evaluation::calculerResultat($data['note_globale']);
        $data['evaluateur_id'] = auth()->id();
        $eval = Evaluation::create($data);
        AuditLog::journal('evaluation', 'evaluations', $eval, [], $eval->toArray());
        return back()->with('success', "Évaluation enregistrée — Note : {$eval->note_globale}/5");
    }

    public function evolution(Salarie $salarie)
    {
        $courbe = Evaluation::where('salarie_id', $salarie->id)->orderBy('annee')->orderBy('trimestre')
            ->get()->map(fn($e) => [
                'label'    => $e->annee . ($e->trimestre ? " T{$e->trimestre}" : " M{$e->mois}"),
                'note'     => $e->note_globale,
                'resultat' => $e->resultat,
            ]);
        return response()->json($courbe);
    }
}
