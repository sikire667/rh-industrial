<?php
namespace App\Http\Controllers;
use App\Models\{Epi, DistributionEpi, AuditLog};
use Illuminate\Http\Request;

class EpiController extends Controller
{
    public function index()
    {
        $epis = Epi::withCount('distributions')->get();
        $distributions = DistributionEpi::with(['salarie','epi','distribuePar'])->orderByDesc('date_distribution')->paginate(20);
        return view('epi.index', compact('epis','distributions'));
    }

    public function distribuer(Request $request)
    {
        $data = $request->validate([
            'salarie_id'        => 'required|exists:salaries,id',
            'epi_id'            => 'required|exists:epis,id',
            'date_distribution' => 'required|date',
            'quantite'          => 'required|integer|min:1',
            'taille'            => 'nullable|string',
            'etat'              => 'required|in:neuf,bon,use,hors_service',
            'notes'             => 'nullable|string',
        ]);
        $epi = Epi::findOrFail($data['epi_id']);
        abort_if($epi->stock_disponible < $data['quantite'], 422, 'Stock insuffisant.');
        $data['distribue_par'] = auth()->id();
        $dist = DistributionEpi::create($data);
        $epi->decrement('stock_disponible', $data['quantite']);
        AuditLog::journal('distribution_epi', 'epi', $dist, [], $dist->toArray());
        return back()->with('success', 'EPI distribué.');
    }
}
