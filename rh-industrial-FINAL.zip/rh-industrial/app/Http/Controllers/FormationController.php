<?php
namespace App\Http\Controllers;
use App\Models\{Formation, SalarieFormation, Salarie, AuditLog};
use Illuminate\Http\Request;

class FormationController extends Controller
{
    public function index(Request $request)
    {
        $formations = SalarieFormation::with(['salarie','formation'])
            ->when($request->statut, fn($q) => $q->where('statut', $request->statut))
            ->when($request->type, fn($q) => $q->whereHas('formation', fn($f) => $f->where('type', $request->type)))
            ->orderBy('date_expiration')->paginate(20)->withQueryString();
        $stats = [
            'total'   => SalarieFormation::count(),
            'valides' => SalarieFormation::where('statut','valide')->count(),
            'bientot' => SalarieFormation::where('statut','bientot_expire')->count(),
            'expires' => SalarieFormation::where('statut','expire')->count(),
        ];
        $catalogues = Formation::orderBy('titre')->get();
        return view('formations.index', compact('formations','stats','catalogues'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'salarie_id'      => 'required|exists:salaries,id',
            'formation_id'    => 'required|exists:formations,id',
            'date_formation'  => 'required|date',
            'date_expiration' => 'nullable|date|after:date_formation',
            'reference'       => 'nullable|string',
            'attestation'     => 'nullable|file|mimes:pdf,jpg,jpeg,png|max:5120',
        ]);
        if ($request->hasFile('attestation')) {
            $data['attestation'] = $request->file('attestation')->store('attestations','public');
        }
        $sf = SalarieFormation::create($data);
        $sf->rafraichirStatut();
        AuditLog::journal('formation', 'formations', $sf, [], $sf->toArray());
        return back()->with('success', 'Formation enregistrée.');
    }
}
