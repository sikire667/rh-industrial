<?php
namespace App\Http\Controllers;
use App\Models\{Absence, Salarie, AuditLog};
use Illuminate\Http\Request;
use Carbon\Carbon;

class AbsenceController extends Controller
{
    public function index(Request $request)
    {
        $query = Absence::with('salarie')
            ->when($request->type, fn($q) => $q->where('type', $request->type))
            ->when($request->statut, fn($q) => $q->where('statut', $request->statut))
            ->when($request->salarie_id, fn($q) => $q->where('salarie_id', $request->salarie_id))
            ->when($request->mois, fn($q) => $q->whereMonth('date_debut', $request->mois))
            ->when($request->annee, fn($q) => $q->whereYear('date_debut', $request->annee));

        $absences = $query->orderByDesc('date_debut')->paginate(20)->withQueryString();
        $stats = [
            'taux'              => Absence::tauxAbsenteisme(now()->year, now()->month),
            'en_attente'        => Absence::where('statut','en_attente')->count(),
            'injustifiees_mois' => Absence::where('type','absence_non_justifiee')->whereMonth('date_debut',now()->month)->count(),
            'conges_mois'       => Absence::where('type','conge_annuel')->whereMonth('date_debut',now()->month)->count(),
        ];
        $historique = collect(range(11, 0))->map(function ($m) {
            $d = Carbon::now()->subMonths($m);
            return ['mois' => $d->format('M y'), 'taux' => Absence::tauxAbsenteisme($d->year, $d->month)];
        });
        return view('absences.index', compact('absences','stats','historique'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'salarie_id'    => 'required|exists:salaries,id',
            'type'          => 'required|in:conge_annuel,conge_maladie,conge_sans_solde,absence_justifiee,absence_non_justifiee,retard',
            'date_debut'    => 'required|date',
            'date_fin'      => 'required|date|after_or_equal:date_debut',
            'motif'         => 'nullable|string',
            'justificatif'  => 'nullable|file|max:5120',
            'heure_retard'  => 'nullable|date_format:H:i',
            'minutes_retard'=> 'nullable|integer|min:1',
        ]);
        $data['nb_jours'] = Carbon::parse($data['date_debut'])->diffInDays($data['date_fin']) + 1;
        $data['statut']   = in_array($data['type'], ['absence_non_justifiee','retard']) ? 'approuve' : 'en_attente';
        if ($request->hasFile('justificatif')) {
            $data['justificatif'] = $request->file('justificatif')->store('justificatifs','public');
        }
        $absence = Absence::create($data);
        AuditLog::journal('creation', 'absences', $absence, [], $absence->toArray());
        return back()->with('success', 'Absence enregistrée.');
    }

    public function valider(Absence $absence)
    {
        $absence->update(['statut' => 'approuve', 'valide_par' => auth()->id(), 'valide_le' => now()]);
        AuditLog::journal('validation', 'absences', $absence);
        return back()->with('success', 'Absence approuvée.');
    }

    public function refuser(Absence $absence)
    {
        $absence->update(['statut' => 'refuse', 'valide_par' => auth()->id(), 'valide_le' => now()]);
        AuditLog::journal('refus', 'absences', $absence);
        return back()->with('success', 'Absence refusée.');
    }

    public function destroy(Absence $absence)
    {
        AuditLog::journal('suppression', 'absences', $absence, $absence->toArray());
        $absence->delete();
        return back()->with('success', 'Absence supprimée.');
    }
}
