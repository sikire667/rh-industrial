<?php
namespace App\Http\Controllers;
use App\Models\{MesureDisciplinaire, AuditLog};
use Illuminate\Http\Request;

class DisciplineController extends Controller
{
    public function index(Request $request)
    {
        $mesures = MesureDisciplinaire::with(['salarie','emisPar'])
            ->when($request->type, fn($q) => $q->where('type', $request->type))
            ->when($request->salarie_id, fn($q) => $q->where('salarie_id', $request->salarie_id))
            ->orderByDesc('date')->paginate(20)->withQueryString();
        $stats = [
            'avertissements' => MesureDisciplinaire::where('type','avertissement')->count(),
            'mises_a_pied'   => MesureDisciplinaire::where('type','mise_a_pied')->count(),
            'observations'   => MesureDisciplinaire::where('type','observation')->count(),
        ];
        return view('disciplines.index', compact('mesures','stats'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'salarie_id'           => 'required|exists:salaries,id',
            'type'                 => 'required|in:observation,avertissement,mise_a_pied,autre',
            'date'                 => 'required|date',
            'motif'                => 'required|string',
            'description'          => 'nullable|string',
            'nb_jours_suspension'  => 'nullable|integer|min:1',
            'fichier'              => 'nullable|file|mimes:pdf,jpg,jpeg|max:5120',
        ]);
        $data['emis_par'] = auth()->id();
        if ($request->hasFile('fichier')) {
            $data['fichier'] = $request->file('fichier')->store('disciplines','public');
        }
        $mesure = MesureDisciplinaire::create($data);
        AuditLog::journal('mesure_disciplinaire', 'disciplines', $mesure, [], $mesure->toArray());
        return back()->with('success', ucfirst($data['type']) . ' enregistré(e).');
    }

    public function cloture(MesureDisciplinaire $mesure)
    {
        $mesure->update(['statut' => 'cloture']);
        AuditLog::journal('cloture_discipline', 'disciplines', $mesure);
        return back()->with('success', 'Mesure clôturée.');
    }
}
