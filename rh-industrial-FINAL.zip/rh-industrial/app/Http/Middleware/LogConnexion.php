<?php
namespace App\Http\Middleware;
use Closure;
use Illuminate\Http\Request;
use App\Models\AuditLog;

class LogConnexion
{
    public function handle(Request $request, Closure $next)
    {
        $response = $next($request);
        if (auth()->check() && $request->is('login') && $request->isMethod('post') && $response->getStatusCode() === 302) {
            auth()->user()->update(['derniere_connexion' => now()]);
            AuditLog::journal('connexion', 'auth');
        }
        return $response;
    }
}
