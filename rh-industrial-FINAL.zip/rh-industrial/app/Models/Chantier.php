<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\{BelongsTo, HasMany};

class Chantier extends Model
{
    use SoftDeletes;
    protected $fillable = ['societe_id','code','nom','localisation','date_debut','date_fin','statut'];
    protected $casts = ['date_debut' => 'date', 'date_fin' => 'date'];
    public function societe(): BelongsTo  { return $this->belongsTo(Societe::class); }
    public function salaries(): HasMany   { return $this->hasMany(Salarie::class); }
    public function getEffectifAttribute(): int { return $this->salaries()->actif()->count(); }
}
