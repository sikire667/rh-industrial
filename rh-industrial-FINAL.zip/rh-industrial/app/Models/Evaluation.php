<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Evaluation extends Model
{
    use SoftDeletes;
    protected $fillable = [
        'salarie_id','evaluateur_id','periode','annee','trimestre','mois',
        'note_ponctualite','note_discipline','note_hse','note_qualite_travail',
        'note_productivite','note_esprit_equipe','note_comportement',
        'note_globale','resultat','commentaires',
    ];

    public function salarie(): BelongsTo    { return $this->belongsTo(Salarie::class); }
    public function evaluateur(): BelongsTo { return $this->belongsTo(User::class, 'evaluateur_id'); }

    public static function calculerNote(array $notes): float
    {
        $valides = array_filter($notes, fn($n) => $n !== null);
        return count($valides) ? round(array_sum($valides) / count($valides), 1) : 0;
    }

    public static function calculerResultat(float $note): string
    {
        return match(true) {
            $note >= 4.5 => 'excellent',
            $note >= 3.5 => 'tres_bien',
            $note >= 2.5 => 'bien',
            $note >= 1.5 => 'a_ameliorer',
            default      => 'insuffisant',
        };
    }
}
