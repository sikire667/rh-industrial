<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Carbon\Carbon;

class Document extends Model
{
    use SoftDeletes;
    protected $fillable = [
        'salarie_id','type','reference','titre','fichier',
        'date_emission','date_expiration','alerte_envoye','notes',
    ];
    protected $casts = [
        'date_emission'   => 'date',
        'date_expiration' => 'date',
        'alerte_envoye'   => 'boolean',
    ];

    public function salarie(): BelongsTo { return $this->belongsTo(Salarie::class); }

    public function getStatutAttribute(): string
    {
        if (!$this->date_expiration) return 'valide';
        $diff = now()->diffInDays($this->date_expiration, false);
        if ($diff < 0)  return 'expire';
        if ($diff <= 30) return 'bientot_expire';
        return 'valide';
    }

    public function getJoursRestantsAttribute(): ?int
    {
        return $this->date_expiration
            ? (int) now()->diffInDays($this->date_expiration, false)
            : null;
    }

    public function scopeExpires($q)
    {
        return $q->whereNotNull('date_expiration')->where('date_expiration', '<', now());
    }
    public function scopeBientotExpires($q, int $jours = 30)
    {
        return $q->whereNotNull('date_expiration')
            ->where('date_expiration', '>=', now())
            ->where('date_expiration', '<=', now()->addDays($jours));
    }
}
