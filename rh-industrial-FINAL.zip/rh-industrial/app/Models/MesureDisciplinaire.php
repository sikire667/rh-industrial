<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class MesureDisciplinaire extends Model
{
    use SoftDeletes;
    protected $fillable = [
        'salarie_id','emis_par','type','date','motif','description',
        'nb_jours_suspension','fichier','statut',
    ];
    protected $casts = ['date' => 'date'];
    public function salarie(): BelongsTo  { return $this->belongsTo(Salarie::class); }
    public function emisPar(): BelongsTo  { return $this->belongsTo(User::class, 'emis_par'); }
}
