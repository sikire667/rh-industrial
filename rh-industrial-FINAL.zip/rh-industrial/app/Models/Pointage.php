<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Pointage extends Model
{
    protected $fillable = [
        'salarie_id','date','heure_entree','heure_sortie',
        'minutes_travailles','heures_supplementaires','minutes_retard','statut','notes',
    ];
    protected $casts = ['date' => 'date'];

    public function salarie(): BelongsTo { return $this->belongsTo(Salarie::class); }

    public function getDureeAttribute(): string
    {
        if (!$this->minutes_travailles) return '—';
        $h = intdiv($this->minutes_travailles, 60);
        $m = $this->minutes_travailles % 60;
        return "{$h}h " . str_pad($m, 2, '0') . "m";
    }

    public static function rapportMensuel(int $annee, int $mois, ?int $chantierId = null)
    {
        $q = static::with('salarie')
            ->whereYear('date', $annee)
            ->whereMonth('date', $mois);
        if ($chantierId) {
            $q->whereHas('salarie', fn($s) => $s->where('chantier_id', $chantierId));
        }
        return $q->get()->groupBy('salarie_id');
    }
}
