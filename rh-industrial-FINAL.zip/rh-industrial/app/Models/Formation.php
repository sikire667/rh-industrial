<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Formation extends Model
{
    protected $fillable = ['titre','type','organisme','duree_validite_mois','description'];
    public function salariesFormations(): HasMany { return $this->hasMany(SalarieFormation::class); }
}
