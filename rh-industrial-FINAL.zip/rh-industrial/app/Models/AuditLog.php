<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class AuditLog extends Model
{
    public $timestamps = false;
    protected $fillable = [
        'user_id','action','module','entite_type','entite_id',
        'donnees_avant','donnees_apres','ip_address','user_agent','created_at',
    ];
    protected $casts = [
        'donnees_avant' => 'array', 'donnees_apres' => 'array', 'created_at' => 'datetime',
    ];
    public function user(): BelongsTo { return $this->belongsTo(User::class); }

    public static function journal(string $action, string $module, $entite = null, array $avant = [], array $apres = []): void
    {
        static::create([
            'user_id'      => auth()->id(),
            'action'       => $action,
            'module'       => $module,
            'entite_type'  => $entite ? get_class($entite) : null,
            'entite_id'    => $entite?->id,
            'donnees_avant' => $avant ?: null,
            'donnees_apres' => $apres ?: null,
            'ip_address'   => request()->ip(),
            'user_agent'   => request()->userAgent(),
            'created_at'   => now(),
        ]);
    }
}
