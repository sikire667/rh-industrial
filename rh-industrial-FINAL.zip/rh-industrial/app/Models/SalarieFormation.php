<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class SalarieFormation extends Model
{
    protected $fillable = [
        'salarie_id','formation_id','date_formation','date_expiration',
        'reference','attestation','alerte_envoye','statut',
    ];
    protected $casts = ['date_formation' => 'date', 'date_expiration' => 'date'];

    public function salarie(): BelongsTo   { return $this->belongsTo(Salarie::class); }
    public function formation(): BelongsTo { return $this->belongsTo(Formation::class); }

    public function scopeExpires($q)       { return $q->where('statut', 'expire'); }
    public function scopeBientotExpires($q){ return $q->where('statut', 'bientot_expire'); }

    public function rafraichirStatut(): void
    {
        if (!$this->date_expiration) return;
        $diff = now()->diffInDays($this->date_expiration, false);
        $this->statut = match(true) {
            $diff < 0  => 'expire',
            $diff <= 60 => 'bientot_expire',
            default    => 'valide',
        };
        $this->save();
    }
}
