<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Epi extends Model
{
    protected $fillable = ['designation','type','norme','reference','stock_disponible','seuil_alerte'];
    public function distributions(): HasMany { return $this->hasMany(DistributionEpi::class); }
    public function getStockAlertAttribute(): bool { return $this->stock_disponible <= $this->seuil_alerte; }
}
