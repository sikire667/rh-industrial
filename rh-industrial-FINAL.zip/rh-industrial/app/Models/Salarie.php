<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Salarie extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'matricule','nom','prenom','cin','telephone','adresse','photo',
        'date_naissance','date_embauche','fonction_id','societe_id',
        'chantier_id','type_contrat','fin_contrat','salaire_base','statut','notes',
    ];

    protected $casts = [
        'date_naissance'  => 'date',
        'date_embauche'   => 'date',
        'fin_contrat'     => 'date',
        'salaire_base'    => 'decimal:2',
    ];

    // ── Relations ──────────────────────────────────────────────────────────
    public function fonction(): BelongsTo   { return $this->belongsTo(Fonction::class); }
    public function societe(): BelongsTo    { return $this->belongsTo(Societe::class); }
    public function chantier(): BelongsTo   { return $this->belongsTo(Chantier::class); }
    public function documents(): HasMany    { return $this->hasMany(Document::class); }
    public function absences(): HasMany     { return $this->hasMany(Absence::class); }
    public function pointages(): HasMany    { return $this->hasMany(Pointage::class); }
    public function disciplines(): HasMany  { return $this->hasMany(MesureDisciplinaire::class); }
    public function evaluations(): HasMany  { return $this->hasMany(Evaluation::class); }
    public function formations(): HasMany   { return $this->hasMany(SalarieFormation::class); }
    public function epis(): HasMany         { return $this->hasMany(DistributionEpi::class); }

    // ── Accessors ──────────────────────────────────────────────────────────
    public function getNomCompletAttribute(): string
    {
        return "{$this->prenom} {$this->nom}";
    }

    public function getAncienneteAttribute(): string
    {
        return $this->date_embauche->diffForHumans(now(), true);
    }

    public function getPhotoUrlAttribute(): string
    {
        return $this->photo
            ? asset('storage/' . $this->photo)
            : asset('images/avatar-default.png');
    }

    // ── Scopes ─────────────────────────────────────────────────────────────
    public function scopeActif($q)           { return $q->where('statut', 'actif'); }
    public function scopeParChantier($q, $id){ return $q->where('chantier_id', $id); }
    public function scopeParContrat($q, $t)  { return $q->where('type_contrat', $t); }

    public function scopeSearch($q, string $term)
    {
        return $q->where(function ($q) use ($term) {
            $q->where('nom',       'like', "%{$term}%")
              ->orWhere('prenom',  'like', "%{$term}%")
              ->orWhere('matricule','like', "%{$term}%")
              ->orWhere('cin',     'like', "%{$term}%");
        });
    }

    // ── Helpers ────────────────────────────────────────────────────────────
    public static function nextMatricule(): string
    {
        $last = static::withTrashed()->max('id') ?? 0;
        return 'MAT-' . str_pad($last + 1, 3, '0', STR_PAD_LEFT);
    }

    public function hasDocumentsExpires(): bool
    {
        return $this->documents()
            ->whereNotNull('date_expiration')
            ->where('date_expiration', '<', now())
            ->exists();
    }

    public function hasFormationsExpirees(): bool
    {
        return $this->formations()
            ->where('statut', 'expire')
            ->exists();
    }
}
