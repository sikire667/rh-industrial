<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Fonction extends Model
{
    protected $fillable = ['libelle','categorie'];
    public function salaries(): HasMany { return $this->hasMany(Salarie::class); }
}
