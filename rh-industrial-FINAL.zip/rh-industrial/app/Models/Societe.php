<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Societe extends Model
{
    use SoftDeletes;
    protected $fillable = ['nom','siret','adresse','telephone','email'];
    public function chantiers(): HasMany { return $this->hasMany(Chantier::class); }
    public function salaries(): HasMany  { return $this->hasMany(Salarie::class); }
}
