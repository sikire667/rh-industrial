<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Absence extends Model
{
    use SoftDeletes;
    protected $fillable = [
        'salarie_id','valide_par','type','date_debut','date_fin',
        'nb_jours','heure_retard','minutes_retard','statut','motif','justificatif','valide_le',
    ];
    protected $casts = [
        'date_debut' => 'date', 'date_fin' => 'date', 'valide_le' => 'datetime',
    ];
    public function salarie(): BelongsTo { return $this->belongsTo(Salarie::class); }
    public function validePar(): BelongsTo { return $this->belongsTo(User::class, 'valide_par'); }

    public function scopeParType($q, $type) { return $q->where('type', $type); }
    public function scopeEnAttente($q) { return $q->where('statut', 'en_attente'); }
    public function scopePeriode($q, $debut, $fin)
    {
        return $q->where('date_debut', '>=', $debut)->where('date_fin', '<=', $fin);
    }

    public static function tauxAbsenteisme(int $annee, int $mois): float
    {
        $nbSalaries = Salarie::actif()->count();
        $joursOuvres = cal_days_in_month(CAL_GREGORIAN, $mois, $annee) * 0.714;
        $joursAbsences = static::whereYear('date_debut', $annee)
            ->whereMonth('date_debut', $mois)
            ->where('statut', 'approuve')
            ->sum('nb_jours');
        $base = $nbSalaries * $joursOuvres;
        return $base > 0 ? round(($joursAbsences / $base) * 100, 2) : 0;
    }
}
