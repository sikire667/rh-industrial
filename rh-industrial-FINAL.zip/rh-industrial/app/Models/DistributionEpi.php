<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class DistributionEpi extends Model
{
    protected $fillable = [
        'salarie_id','epi_id','distribue_par','date_distribution',
        'quantite','taille','date_retour','etat','notes',
    ];
    protected $casts = ['date_distribution' => 'date', 'date_retour' => 'date'];
    public function salarie(): BelongsTo      { return $this->belongsTo(Salarie::class); }
    public function epi(): BelongsTo          { return $this->belongsTo(Epi::class); }
    public function distribuePar(): BelongsTo { return $this->belongsTo(User::class, 'distribue_par'); }
}
