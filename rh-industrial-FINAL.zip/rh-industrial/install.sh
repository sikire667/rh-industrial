#!/usr/bin/env bash
set -e

GREEN="\033[1;32m"; BLUE="\033[1;34m"; YELLOW="\033[1;33m"; RED="\033[1;31m"; NC="\033[0m"
info()  { echo -e "${BLUE}ℹ  $1${NC}"; }
ok()    { echo -e "${GREEN}✅ $1${NC}"; }
warn()  { echo -e "${YELLOW}⚠  $1${NC}"; }
error() { echo -e "${RED}❌ $1${NC}"; exit 1; }

clear
echo -e "${GREEN}"
cat << 'BANNER'
╔══════════════════════════════════════════════════════════╗
║          RH Industrial Pro — Installateur v3.2           ║
║     Application RH • Chantier & Maintenance Industrielle ║
╚══════════════════════════════════════════════════════════╝
BANNER
echo -e "${NC}"

# ── Prérequis ────────────────────────────────────────────────────────────────
info "Vérification des prérequis..."
command -v php  >/dev/null 2>&1 || error "PHP non installé (requis >= 8.2)"
command -v composer >/dev/null 2>&1 || error "Composer non installé"
command -v npm  >/dev/null 2>&1 || error "Node.js/npm non installé"
command -v mysql >/dev/null 2>&1 || warn "MySQL CLI non détecté (vérifiez votre serveur)"

PHP_VER=$(php -r "echo PHP_MAJOR_VERSION.'.'.PHP_MINOR_VERSION;")
info "PHP $PHP_VER détecté"
ok "Prérequis OK"

# ── Configuration .env ───────────────────────────────────────────────────────
echo ""
info "Configuration de la base de données"
echo -n "  Hôte MySQL [127.0.0.1]: "; read DB_HOST;  DB_HOST=${DB_HOST:-127.0.0.1}
echo -n "  Port       [3306]: ";       read DB_PORT;  DB_PORT=${DB_PORT:-3306}
echo -n "  Nom BDD    [rh_industrial]: "; read DB_NAME; DB_NAME=${DB_NAME:-rh_industrial}
echo -n "  Utilisateur [root]: ";      read DB_USER;  DB_USER=${DB_USER:-root}
echo -n "  Mot de passe: ";            read -s DB_PASS; echo ""

cp .env.example .env
sed -i "s/DB_HOST=127.0.0.1/DB_HOST=${DB_HOST}/" .env
sed -i "s/DB_PORT=3306/DB_PORT=${DB_PORT}/" .env
sed -i "s/DB_DATABASE=rh_industrial/DB_DATABASE=${DB_NAME}/" .env
sed -i "s/DB_USERNAME=root/DB_USERNAME=${DB_USER}/" .env
sed -i "s/DB_PASSWORD=/DB_PASSWORD=${DB_PASS}/" .env
ok ".env configuré"

# ── Création BDD ─────────────────────────────────────────────────────────────
info "Création de la base de données '${DB_NAME}'..."
mysql -h"$DB_HOST" -P"$DB_PORT" -u"$DB_USER" -p"$DB_PASS" \
  -e "CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;" \
  2>/dev/null && ok "Base de données créée" || warn "Création BDD ignorée (peut déjà exister)"

# ── Dépendances PHP ──────────────────────────────────────────────────────────
echo ""
info "Installation des dépendances PHP (Composer)..."
composer install --no-interaction --prefer-dist --optimize-autoloader
ok "Dépendances PHP installées"

# ── Clé d'application ────────────────────────────────────────────────────────
php artisan key:generate --ansi
ok "Clé d'application générée"

# ── Migrations & Seed ────────────────────────────────────────────────────────
info "Migration de la base de données..."
php artisan migrate --force
ok "Migrations exécutées"

info "Injection des données de démonstration..."
php artisan db:seed --force
ok "Données de démo injectées"

# ── Dépendances JS ───────────────────────────────────────────────────────────
echo ""
info "Installation des dépendances JS (npm)..."
npm install
ok "Dépendances JS installées"

info "Compilation des assets (Vite/Tailwind)..."
npm run build
ok "Assets compilés"

# ── Storage link ─────────────────────────────────────────────────────────────
php artisan storage:link
ok "Lien storage créé"

# ── Permissions ──────────────────────────────────────────────────────────────
chmod -R 775 storage bootstrap/cache
ok "Permissions OK"

# ── Tâche CRON (optionnel) ───────────────────────────────────────────────────
echo ""
warn "Tâche CRON pour alertes automatiques — ajoutez dans votre crontab :"
echo -e "  ${YELLOW}* * * * * cd $(pwd) && php artisan schedule:run >> /dev/null 2>&1${NC}"

# ── Résumé ───────────────────────────────────────────────────────────────────
echo ""
echo -e "${GREEN}"
cat << 'DONE'
╔══════════════════════════════════════════════════════════╗
║               ✅  Installation terminée !                ║
╠══════════════════════════════════════════════════════════╣
║                                                          ║
║  Démarrer le serveur :                                   ║
║    php artisan serve                                     ║
║                                                          ║
║  URL :  http://localhost:8000                            ║
║                                                          ║
║  Connexion admin :                                       ║
║    Email    → admin@rh-industrial.ma                     ║
║    Mot de passe → password                               ║
║                                                          ║
║  Connexion RH :                                          ║
║    Email    → rh@rh-industrial.ma                        ║
║    Mot de passe → password                               ║
║                                                          ║
║  Artisan utiles :                                        ║
║    php artisan rh:alertes      # Vérifier alertes        ║
║    php artisan migrate:fresh --seed  # Reset démo        ║
║    php artisan queue:work      # Activer la queue        ║
╚══════════════════════════════════════════════════════════╝
DONE
echo -e "${NC}"
