<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // ─── SOCIÉTÉS ───────────────────────────────────────────────────────
        Schema::create('societes', function (Blueprint $table) {
            $table->id();
            $table->string('nom');
            $table->string('siret', 20)->nullable();
            $table->string('adresse')->nullable();
            $table->string('telephone', 20)->nullable();
            $table->string('email')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });

        // ─── CHANTIERS ──────────────────────────────────────────────────────
        Schema::create('chantiers', function (Blueprint $table) {
            $table->id();
            $table->foreignId('societe_id')->constrained()->cascadeOnDelete();
            $table->string('code', 20)->unique();
            $table->string('nom');
            $table->string('localisation')->nullable();
            $table->date('date_debut')->nullable();
            $table->date('date_fin')->nullable();
            $table->enum('statut', ['actif', 'termine', 'suspendu'])->default('actif');
            $table->timestamps();
            $table->softDeletes();
        });

        // ─── FONCTIONS ──────────────────────────────────────────────────────
        Schema::create('fonctions', function (Blueprint $table) {
            $table->id();
            $table->string('libelle');
            $table->string('categorie')->nullable();
            $table->timestamps();
        });

        // ─── SALARIÉS ───────────────────────────────────────────────────────
        Schema::create('salaries', function (Blueprint $table) {
            $table->id();
            $table->string('matricule', 20)->unique();
            $table->string('nom');
            $table->string('prenom');
            $table->string('cin', 20)->unique();
            $table->string('telephone', 20)->nullable();
            $table->text('adresse')->nullable();
            $table->string('photo')->nullable();
            $table->date('date_naissance')->nullable();
            $table->date('date_embauche');
            $table->foreignId('fonction_id')->nullable()->constrained('fonctions');
            $table->foreignId('societe_id')->constrained('societes');
            $table->foreignId('chantier_id')->nullable()->constrained('chantiers');
            $table->enum('type_contrat', ['CDI', 'CDD', 'Interim'])->default('CDI');
            $table->date('fin_contrat')->nullable();
            $table->decimal('salaire_base', 10, 2)->nullable();
            $table->enum('statut', ['actif', 'inactif', 'suspendu'])->default('actif');
            $table->text('notes')->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->index(['statut', 'chantier_id']);
            $table->index('type_contrat');
        });

        // ─── DOCUMENTS ──────────────────────────────────────────────────────
        Schema::create('documents', function (Blueprint $table) {
            $table->id();
            $table->foreignId('salarie_id')->constrained('salaries')->cascadeOnDelete();
            $table->enum('type', [
                'contrat', 'cin', 'diplome', 'certificat_medical',
                'habilitation', 'permis', 'attestation', 'autre'
            ]);
            $table->string('reference')->nullable();
            $table->string('titre');
            $table->string('fichier')->nullable();
            $table->date('date_emission')->nullable();
            $table->date('date_expiration')->nullable();
            $table->boolean('alerte_envoye')->default(false);
            $table->text('notes')->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->index(['salarie_id', 'type']);
            $table->index('date_expiration');
        });

        // ─── ABSENCES ───────────────────────────────────────────────────────
        Schema::create('absences', function (Blueprint $table) {
            $table->id();
            $table->foreignId('salarie_id')->constrained('salaries')->cascadeOnDelete();
            $table->foreignId('valide_par')->nullable()->constrained('users');
            $table->enum('type', [
                'conge_annuel', 'conge_maladie', 'conge_sans_solde',
                'absence_justifiee', 'absence_non_justifiee', 'retard'
            ]);
            $table->date('date_debut');
            $table->date('date_fin');
            $table->integer('nb_jours')->default(1);
            $table->time('heure_retard')->nullable();
            $table->integer('minutes_retard')->nullable();
            $table->enum('statut', ['en_attente', 'approuve', 'refuse'])->default('en_attente');
            $table->text('motif')->nullable();
            $table->string('justificatif')->nullable();
            $table->timestamp('valide_le')->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->index(['salarie_id', 'type', 'date_debut']);
        });

        // ─── POINTAGES ──────────────────────────────────────────────────────
        Schema::create('pointages', function (Blueprint $table) {
            $table->id();
            $table->foreignId('salarie_id')->constrained('salaries')->cascadeOnDelete();
            $table->date('date');
            $table->time('heure_entree')->nullable();
            $table->time('heure_sortie')->nullable();
            $table->integer('minutes_travailles')->nullable();
            $table->integer('heures_supplementaires')->default(0);
            $table->integer('minutes_retard')->default(0);
            $table->enum('statut', ['present', 'absent', 'conge', 'jour_ferie'])->default('present');
            $table->text('notes')->nullable();
            $table->timestamps();

            $table->unique(['salarie_id', 'date']);
            $table->index('date');
        });

        // ─── MESURES DISCIPLINAIRES ─────────────────────────────────────────
        Schema::create('mesures_disciplinaires', function (Blueprint $table) {
            $table->id();
            $table->foreignId('salarie_id')->constrained('salaries')->cascadeOnDelete();
            $table->foreignId('emis_par')->constrained('users');
            $table->enum('type', ['observation', 'avertissement', 'mise_a_pied', 'autre']);
            $table->date('date');
            $table->text('motif');
            $table->text('description')->nullable();
            $table->integer('nb_jours_suspension')->nullable();
            $table->string('fichier')->nullable();
            $table->enum('statut', ['actif', 'cloture'])->default('actif');
            $table->timestamps();
            $table->softDeletes();

            $table->index(['salarie_id', 'type']);
        });

        // ─── ÉVALUATIONS ────────────────────────────────────────────────────
        Schema::create('evaluations', function (Blueprint $table) {
            $table->id();
            $table->foreignId('salarie_id')->constrained('salaries')->cascadeOnDelete();
            $table->foreignId('evaluateur_id')->constrained('users');
            $table->enum('periode', ['mensuel', 'trimestriel', 'annuel']);
            $table->string('annee', 4);
            $table->tinyInteger('trimestre')->nullable();
            $table->tinyInteger('mois')->nullable();
            // Critères notés de 1 à 5
            $table->tinyInteger('note_ponctualite')->nullable();
            $table->tinyInteger('note_discipline')->nullable();
            $table->tinyInteger('note_hse')->nullable();
            $table->tinyInteger('note_qualite_travail')->nullable();
            $table->tinyInteger('note_productivite')->nullable();
            $table->tinyInteger('note_esprit_equipe')->nullable();
            $table->tinyInteger('note_comportement')->nullable();
            $table->decimal('note_globale', 3, 1)->nullable();
            $table->enum('resultat', ['insuffisant', 'a_ameliorer', 'bien', 'tres_bien', 'excellent'])->nullable();
            $table->text('commentaires')->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->unique(['salarie_id', 'periode', 'annee', 'trimestre', 'mois']);
            $table->index(['salarie_id', 'annee']);
        });

        // ─── FORMATIONS ─────────────────────────────────────────────────────
        Schema::create('formations', function (Blueprint $table) {
            $table->id();
            $table->string('titre');
            $table->enum('type', ['SST', 'HSE', 'habilitation', 'permis', 'technique', 'autre']);
            $table->string('organisme')->nullable();
            $table->integer('duree_validite_mois')->default(24);
            $table->text('description')->nullable();
            $table->timestamps();
        });

        Schema::create('salarie_formations', function (Blueprint $table) {
            $table->id();
            $table->foreignId('salarie_id')->constrained('salaries')->cascadeOnDelete();
            $table->foreignId('formation_id')->constrained('formations');
            $table->date('date_formation');
            $table->date('date_expiration')->nullable();
            $table->string('reference')->nullable();
            $table->string('attestation')->nullable();
            $table->boolean('alerte_envoye')->default(false);
            $table->enum('statut', ['valide', 'expire', 'bientot_expire'])->default('valide');
            $table->timestamps();

            $table->index(['salarie_id', 'statut']);
            $table->index('date_expiration');
        });

        // ─── EPI ────────────────────────────────────────────────────────────
        Schema::create('epis', function (Blueprint $table) {
            $table->id();
            $table->string('designation');
            $table->string('type');
            $table->string('norme')->nullable();
            $table->string('reference')->nullable();
            $table->integer('stock_disponible')->default(0);
            $table->integer('seuil_alerte')->default(5);
            $table->timestamps();
        });

        Schema::create('distributions_epi', function (Blueprint $table) {
            $table->id();
            $table->foreignId('salarie_id')->constrained('salaries')->cascadeOnDelete();
            $table->foreignId('epi_id')->constrained('epis');
            $table->foreignId('distribue_par')->constrained('users');
            $table->date('date_distribution');
            $table->integer('quantite')->default(1);
            $table->string('taille')->nullable();
            $table->date('date_retour')->nullable();
            $table->enum('etat', ['neuf', 'bon', 'use', 'hors_service'])->default('neuf');
            $table->text('notes')->nullable();
            $table->timestamps();
        });

        // ─── JOURNAL D'AUDIT ─────────────────────────────────────────────────
        Schema::create('audit_logs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->nullable()->constrained('users');
            $table->string('action');
            $table->string('module');
            $table->string('entite_type')->nullable();
            $table->unsignedBigInteger('entite_id')->nullable();
            $table->json('donnees_avant')->nullable();
            $table->json('donnees_apres')->nullable();
            $table->string('ip_address', 45)->nullable();
            $table->string('user_agent')->nullable();
            $table->timestamp('created_at')->useCurrent();

            $table->index(['module', 'created_at']);
            $table->index(['entite_type', 'entite_id']);
        });

        // ─── ROLES UTILISATEURS ──────────────────────────────────────────────
        Schema::create('roles', function (Blueprint $table) {
            $table->id();
            $table->string('nom')->unique();
            $table->json('permissions')->nullable();
            $table->timestamps();
        });

        Schema::table('users', function (Blueprint $table) {
            $table->foreignId('role_id')->nullable()->constrained('roles');
            $table->foreignId('chantier_id')->nullable()->constrained('chantiers');
            $table->boolean('actif')->default(true);
            $table->timestamp('derniere_connexion')->nullable();
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn(['role_id', 'chantier_id', 'actif', 'derniere_connexion']);
        });
        Schema::dropIfExists('audit_logs');
        Schema::dropIfExists('distributions_epi');
        Schema::dropIfExists('epis');
        Schema::dropIfExists('salarie_formations');
        Schema::dropIfExists('formations');
        Schema::dropIfExists('evaluations');
        Schema::dropIfExists('mesures_disciplinaires');
        Schema::dropIfExists('pointages');
        Schema::dropIfExists('absences');
        Schema::dropIfExists('documents');
        Schema::dropIfExists('salaries');
        Schema::dropIfExists('fonctions');
        Schema::dropIfExists('chantiers');
        Schema::dropIfExists('societes');
        Schema::dropIfExists('roles');
    }
};
