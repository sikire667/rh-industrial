<?php
namespace Database\Seeders;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\{Hash, DB};
use Carbon\Carbon;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        DB::statement('SET FOREIGN_KEY_CHECKS=0;');

        // Rôles
        $adminId = DB::table('roles')->insertGetId([
            'nom' => 'Administrateur',
            'permissions' => json_encode(['*']),
            'created_at' => now(), 'updated_at' => now(),
        ]);
        $rhId = DB::table('roles')->insertGetId([
            'nom' => 'RH Manager',
            'permissions' => json_encode(['salaries.*','absences.*','pointage.*','documents.*','evaluations.*','formations.*','epi.*','disciplines.*','rapports.*']),
            'created_at' => now(), 'updated_at' => now(),
        ]);
        DB::table('roles')->insertGetId([
            'nom' => 'Superviseur Chantier',
            'permissions' => json_encode(['pointage.*','absences.read','salaries.read']),
            'created_at' => now(), 'updated_at' => now(),
        ]);

        // Utilisateurs
        $adminUserId = DB::table('users')->insertGetId([
            'name' => 'Ahmed Mansouri', 'email' => 'admin@rh-industrial.ma',
            'password' => Hash::make('password'), 'role_id' => $adminId,
            'created_at' => now(), 'updated_at' => now(),
        ]);
        DB::table('users')->insert([
            'name' => 'Fatima Zahra Idrissi', 'email' => 'rh@rh-industrial.ma',
            'password' => Hash::make('password'), 'role_id' => $rhId,
            'created_at' => now(), 'updated_at' => now(),
        ]);

        // Société
        $societeId = DB::table('societes')->insertGetId([
            'nom' => 'IndusMaint SARL', 'siret' => 'MA-RC-12345',
            'adresse' => 'Zone Industrielle, Casablanca', 'telephone' => '05-22-XX-XX-XX',
            'email' => 'contact@indusmaint.ma', 'created_at' => now(), 'updated_at' => now(),
        ]);

        // Chantiers
        $chantierIds = [];
        foreach ([
            ['MAT-A', 'Chantier Mehdia A', 'Mehdia, Kénitra'],
            ['SAF-B', 'Chantier Safi B', 'Safi'],
            ['JRF-C', 'Chantier Jorf C', 'Jorf Lasfar'],
        ] as [$code, $nom, $lieu]) {
            $chantierIds[] = DB::table('chantiers')->insertGetId([
                'societe_id' => $societeId, 'code' => $code, 'nom' => $nom,
                'localisation' => $lieu, 'statut' => 'actif',
                'date_debut' => '2023-01-01', 'created_at' => now(), 'updated_at' => now(),
            ]);
        }

        // Fonctions
        $fonctions = [];
        foreach (['Chef de chantier','Soudeur industriel','Électricien N3','Mécanicien industriel','Opérateur maintenance','Chargé HSE','Tuyauteur','Technicien instrumentation'] as $f) {
            $fonctions[] = DB::table('fonctions')->insertGetId(['libelle' => $f, 'created_at' => now(), 'updated_at' => now()]);
        }

        // EPI
        foreach ([
            ['Casque de sécurité','Tête','EN 397','CSQ-001',24,5],
            ['Harnais anti-chute','Hauteur','EN 361','HAR-001',8,3],
            ['Lunettes de protection','Yeux','EN 166','LUN-001',30,10],
            ['Gants de travail','Mains','EN 388','GNT-001',50,15],
            ['Chaussures de sécurité','Pieds','EN ISO 20345','CHS-001',20,5],
            ['Masque respiratoire','Respiration','EN 149','MSQ-001',15,5],
            ['Gilet haute visibilité','Corps','EN ISO 20471','GHV-001',40,10],
        ] as [$desig,$type,$norme,$ref,$stock,$seuil]) {
            DB::table('epis')->insert([
                'designation' => $desig, 'type' => $type, 'norme' => $norme,
                'reference' => $ref, 'stock_disponible' => $stock, 'seuil_alerte' => $seuil,
                'created_at' => now(), 'updated_at' => now(),
            ]);
        }

        // Formations catalogue
        $formationIds = [];
        foreach ([
            ['SST — Sauveteur Secouriste du Travail','SST',24],
            ['Travaux en hauteur','HSE',12],
            ['Habilitation électrique B2V','habilitation',36],
            ['Permis nacelle R486','permis',60],
            ['ATEX — Atmosphères explosives','HSE',24],
            ['Gestes et postures','HSE',36],
        ] as [$titre,$type,$duree]) {
            $formationIds[] = DB::table('formations')->insertGetId([
                'titre' => $titre, 'type' => $type, 'duree_validite_mois' => $duree,
                'organisme' => 'Centre Formation Sécurité Maroc',
                'created_at' => now(), 'updated_at' => now(),
            ]);
        }

        // Salariés
        $salaries = [
            ['MAT-001','Alami','Mohamed','AB123456','06 61 12 34 56',0,0,'CDI','2019-03-15',null,0],
            ['MAT-002','Haddad','Youssef','CD789012','06 62 23 45 67',1,1,'CDD','2022-07-02','2025-07-02',1],
            ['MAT-003','Benali','Karim','EF345678','06 63 34 56 78',2,0,'Interim','2024-01-10','2025-06-30',2],
            ['MAT-004','Said','Omar','GH901234','06 64 45 67 89',3,0,'CDI','2020-09-22',null,0],
            ['MAT-005','Fadel','Ali','IJ567890','06 65 56 78 90',4,1,'CDD','2023-04-05','2025-09-05',1],
            ['MAT-006','Mansouri','Rachid','KL123456','06 66 67 89 01',5,2,'CDI','2018-06-01',null,2],
            ['MAT-007','Ouali','Hassan','MN234567','06 67 78 90 12',6,1,'CDI','2021-02-15',null,0],
            ['MAT-008','Tahiri','Yassine','OP345678','06 68 89 01 23',7,2,'Interim','2024-03-01','2025-08-31',1],
        ];

        $salarieIds = [];
        foreach ($salaries as $i => [$mat,$nom,$prenom,$cin,$tel,$fonctionIdx,$chantierIdx,$contrat,$embauche,$fin,$sfIdx]) {
            $salarieIds[] = DB::table('salaries')->insertGetId([
                'matricule' => $mat, 'nom' => $nom, 'prenom' => $prenom,
                'cin' => $cin, 'telephone' => $tel,
                'adresse' => 'Quartier ' . ['Hassan','Agdal','Hay Riad','Guéliz','Samlalia'][$i % 5] . ', Maroc',
                'date_embauche' => $embauche,
                'fonction_id' => $fonctions[$fonctionIdx],
                'societe_id' => $societeId,
                'chantier_id' => $chantierIds[$chantierIdx],
                'type_contrat' => $contrat,
                'fin_contrat' => $fin,
                'statut' => 'actif',
                'created_at' => now(), 'updated_at' => now(),
            ]);
        }

        // Documents (avec expirés pour les alertes)
        $docs = [
            [$salarieIds[0],'cin','AB123456','CIN Mohamed Alami','2019-01-01','2025-12-31'],
            [$salarieIds[0],'contrat','CDI-2019-001','Contrat CDI Mohamed Alami','2019-03-15',null],
            [$salarieIds[1],'cin','CD789012','CIN Youssef Haddad','2018-06-01','2026-06-01'],
            [$salarieIds[2],'cin','EF345678','CIN Karim Benali','2019-06-12','2025-06-09'],   // EXPIRÉ
            [$salarieIds[2],'habilitation','HAB-ELEC-001','Habilitation électrique Karim','2023-01-01','2025-06-15'],  // BIENTOT
            [$salarieIds[3],'habilitation','HAB-ELEC-B2','Habilitation B2V Omar Said','2023-06-19','2025-06-19'],   // BIENTOT
            [$salarieIds[4],'permis','NACELLE-001','Permis nacelle Ali Fadel','2022-01-01','2024-01-01'],  // EXPIRÉ
        ];

        foreach ($docs as [$sid,$type,$ref,$titre,$emission,$expiration]) {
            DB::table('documents')->insert([
                'salarie_id' => $sid, 'type' => $type, 'reference' => $ref,
                'titre' => $titre, 'date_emission' => $emission, 'date_expiration' => $expiration,
                'created_at' => now(), 'updated_at' => now(),
            ]);
        }

        // Formations salariés
        foreach ($salarieIds as $i => $sid) {
            DB::table('salarie_formations')->insert([
                'salarie_id' => $sid,
                'formation_id' => $formationIds[$i % count($formationIds)],
                'date_formation' => Carbon::now()->subMonths(rand(6, 36))->format('Y-m-d'),
                'date_expiration' => Carbon::now()->addMonths(rand(-3, 18))->format('Y-m-d'),
                'statut' => 'valide',
                'created_at' => now(), 'updated_at' => now(),
            ]);
        }

        // Absences
        DB::table('absences')->insert([
            ['salarie_id'=>$salarieIds[1],'type'=>'absence_non_justifiee','date_debut'=>'2025-06-07','date_fin'=>'2025-06-07','nb_jours'=>1,'statut'=>'approuve','motif'=>'Absence non justifiée','created_at'=>now(),'updated_at'=>now()],
            ['salarie_id'=>$salarieIds[4],'type'=>'conge_annuel','date_debut'=>'2025-06-12','date_fin'=>'2025-06-18','nb_jours'=>7,'statut'=>'en_attente','motif'=>'Congé annuel planifié','created_at'=>now(),'updated_at'=>now()],
            ['salarie_id'=>$salarieIds[3],'type'=>'conge_maladie','date_debut'=>'2025-06-09','date_fin'=>'2025-06-11','nb_jours'=>3,'statut'=>'en_attente','motif'=>'Certificat médical','created_at'=>now(),'updated_at'=>now()],
        ]);

        // Mesures disciplinaires
        DB::table('mesures_disciplinaires')->insert([
            ['salarie_id'=>$salarieIds[1],'emis_par'=>$adminUserId,'type'=>'mise_a_pied','date'=>'2025-06-01','motif'=>'Absences répétées non justifiées','statut'=>'actif','created_at'=>now(),'updated_at'=>now()],
            ['salarie_id'=>$salarieIds[2],'emis_par'=>$adminUserId,'type'=>'avertissement','date'=>'2025-05-28','motif'=>'Retards répétés (4 fois ce mois)','statut'=>'actif','created_at'=>now(),'updated_at'=>now()],
            ['salarie_id'=>$salarieIds[4],'emis_par'=>$adminUserId,'type'=>'observation','date'=>'2025-05-22','motif'=>'Non-port EPI sur chantier','statut'=>'cloture','created_at'=>now(),'updated_at'=>now()],
        ]);

        // Pointages aujourd'hui
        $today = Carbon::today()->format('Y-m-d');
        foreach ($salarieIds as $i => $sid) {
            $present = $i !== 1; // Youssef absent
            DB::table('pointages')->insert([
                'salarie_id' => $sid,
                'date' => $today,
                'heure_entree' => $present ? (sprintf('%02d', 7 + ($i % 2)) . ':' . sprintf('%02d', rand(45,59))) : null,
                'heure_sortie' => null,
                'minutes_travailles' => $present ? (rand(420, 540)) : null,
                'heures_supplementaires' => $present ? rand(0, 90) : 0,
                'minutes_retard' => ($present && $i === 2) ? 47 : 0,
                'statut' => $present ? 'present' : 'absent',
                'created_at' => now(), 'updated_at' => now(),
            ]);
        }

        // Évaluations
        foreach ($salarieIds as $i => $sid) {
            $notes = [rand(3,5), rand(3,5), rand(3,5), rand(2,5), rand(3,5), rand(2,5), rand(3,5)];
            $moy = round(array_sum($notes) / count($notes), 1);
            DB::table('evaluations')->insert([
                'salarie_id' => $sid, 'evaluateur_id' => $adminUserId,
                'periode' => 'trimestriel', 'annee' => '2025', 'trimestre' => 2,
                'note_ponctualite' => $notes[0], 'note_discipline' => $notes[1],
                'note_hse' => $notes[2], 'note_qualite_travail' => $notes[3],
                'note_productivite' => $notes[4], 'note_esprit_equipe' => $notes[5],
                'note_comportement' => $notes[6], 'note_globale' => $moy,
                'resultat' => $moy >= 4.5 ? 'excellent' : ($moy >= 3.5 ? 'tres_bien' : ($moy >= 2.5 ? 'bien' : 'a_ameliorer')),
                'created_at' => now(), 'updated_at' => now(),
            ]);
        }

        // Journal audit
        $actions = [
            ['Ahmed Mansouri', 'creation', 'salaries', 'Création du salarié Rachid Ouhbi (MAT-009)'],
            ['Ahmed Mansouri', 'modification', 'salaries', 'Modification contrat Youssef Haddad (CDD → CDI)'],
            ['Système', 'alerte_expiration', 'documents', 'Alerte: CIN expiré pour Karim Benali'],
            ['Fatima Zahra Idrissi', 'pointage', 'pointages', 'Pointage journalier enregistré — 8 salariés'],
            ['Ahmed Mansouri', 'validation', 'absences', 'Validation congé annuel — Ali Fadel'],
            ['Ahmed Mansouri', 'distribution_epi', 'epi', 'Distribution casque de sécurité — Mohamed Alami'],
        ];

        foreach ($actions as [$user, $action, $module, $desc]) {
            DB::table('audit_logs')->insert([
                'user_id' => $adminUserId,
                'action' => $action,
                'module' => $module,
                'ip_address' => '192.168.1.' . rand(1, 50),
                'created_at' => Carbon::now()->subMinutes(rand(5, 480)),
            ]);
        }

        DB::statement('SET FOREIGN_KEY_CHECKS=1;');
        $this->command->info('✅ Base de données peuplée avec succès !');
    }
}
